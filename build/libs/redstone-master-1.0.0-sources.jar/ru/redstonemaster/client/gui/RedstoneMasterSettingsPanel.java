package ru.redstonemaster.client.gui;

import ru.redstonemaster.client.gui.settings.ModSetting;
import ru.redstonemaster.config.ModConfig;
import ru.redstonemaster.config.ModContentLanguage;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_7919;

final class RedstoneMasterSettingsPanel {
	static final int SEARCH_HEIGHT = 20;
	private static final int ROW_HEIGHT = 20;
	private static final int ROW_GAP = 2;
	private static final int SEARCH_BOTTOM_GAP = 8;
	private static final int DISCLAIMER_GAP = 4;
	private static final String DISCLAIMER_KEY = "gui.redstone-master.settings.disclaimer";
	private static final String INTERFACE_SECTION_KEY = "gui.redstone-master.settings.section.interface";
	private static final String CONTROLS_SECTION_KEY = "gui.redstone-master.settings.section.controls";
	private static final String TUTORIAL_SECTION_KEY = "gui.redstone-master.settings.section.tutorial";
	private static final int VALUE_BUTTON_WIDTH = 110;
	private static final int RESET_BUTTON_MIN_WIDTH = 44;
	private static final int RESET_BUTTON_PADDING = 8;
	private static final int RESET_BUTTON_GAP = 2;
	private static final int RESET_ALL_GAP = 6;
	private static final int TEXT_COLOR = 0xFFFFFFFF;
	private static final int SECTION_COLOR = 0xFFE8C070;
	private static final int DISCLAIMER_COLOR = 0xFFBBBBBB;

	private final RedstoneMasterScreen screen;
	private class_342 searchBox;
	private String searchQuery = "";
	private int scrollOffset;
	private final List<LayoutRow> layoutRows = new ArrayList<>();
	private final List<class_4185> valueButtons = new ArrayList<>();
	private final List<class_4185> resetButtons = new ArrayList<>();
	private class_4185 resetAllButton;

	RedstoneMasterSettingsPanel(RedstoneMasterScreen screen) {
		this.screen = screen;
	}

	void rebuildWidgets() {
		this.layoutRows.clear();
		this.valueButtons.clear();
		this.resetButtons.clear();
		this.resetAllButton = null;

		int innerX = this.screen.getContentX() + RedstoneMasterScreen.CONTENT_INNER_PADDING;
		int innerWidth = this.screen.getContentWidth() - RedstoneMasterScreen.CONTENT_INNER_PADDING * 2;
		int searchY = this.getSearchY();
		int searchHeight = this.getSearchHeight();
		int y = this.getListTop();
		int disclaimerHeight = this.getDisclaimerHeight(innerWidth);
		this.layoutRows.add(LayoutRow.disclaimer(y, disclaimerHeight));
		y += disclaimerHeight + DISCLAIMER_GAP;

		int resetButtonWidth = this.getResetButtonWidth();
		int controlsWidth = resetButtonWidth + RESET_BUTTON_GAP;
		int valueButtonWidth = Math.min(
				VALUE_BUTTON_WIDTH,
				Math.max(48, innerWidth - controlsWidth - 80)
		);
		controlsWidth += valueButtonWidth;
		int valueButtonX = innerX + innerWidth - controlsWidth;
		int resetButtonX = valueButtonX + valueButtonWidth + RESET_BUTTON_GAP;
		int labelWidth = innerWidth - controlsWidth - 12;
		Set<String> addedSections = new LinkedHashSet<>();

		for (ModSetting setting : ModSetting.values()) {
			if (!setting.matchesSearch(this.searchQuery)) {
				continue;
			}
			if (addedSections.add(setting.getSectionKey())) {
				if (INTERFACE_SECTION_KEY.equals(setting.getSectionKey())
						|| CONTROLS_SECTION_KEY.equals(setting.getSectionKey())
						|| TUTORIAL_SECTION_KEY.equals(setting.getSectionKey())) {
					y += this.screen.method_64506().field_2000;
				}
				this.layoutRows.add(LayoutRow.section(setting.getSectionKey(), y));
				y += this.screen.method_64506().field_2000 * 2;
			}

			int lineCount = this.getSettingLineCount(setting, labelWidth);
			int rowHeight = this.getSettingRowHeight(lineCount);
			int buttonY = this.getSettingButtonY(y, rowHeight);
			this.layoutRows.add(LayoutRow.setting(setting, y, rowHeight));
			class_4185 valueButton = this.createValueButton(setting, valueButtonX, buttonY, valueButtonWidth);
			this.valueButtons.add(valueButton);
			this.screen.addContentWidget(valueButton);
			class_4185 resetButton = this.createResetButton(setting, resetButtonX, buttonY, resetButtonWidth);
			this.resetButtons.add(resetButton);
			this.screen.addContentWidget(resetButton);
			y += rowHeight + ROW_GAP;
		}

		ModConfig config = ModConfig.get();
		this.resetAllButton = class_4185.method_46430(
						ModContentLanguage.translatable("gui.redstone-master.settings.reset_all"),
						button -> this.openResetAllConfirm())
				.method_46434(innerX, this.getResetAllButtonY(), innerWidth, ROW_HEIGHT)
				.method_46431();
		this.resetAllButton.field_22763 = !config.areAllModSettingsAtDefault();
		this.screen.addContentWidget(this.resetAllButton);

		this.searchBox = new class_342(
				this.screen.method_64506(),
				innerX,
				searchY,
				innerWidth,
				searchHeight,
				ModContentLanguage.translatable("gui.redstone-master.settings.search_hint")
		);
		this.searchBox.method_1880(64);
		this.searchBox.method_47404(ModContentLanguage.translatable("gui.redstone-master.settings.search_hint"));
		this.searchBox.method_1852(this.searchQuery);
		this.searchBox.method_1863(value -> {
			this.searchQuery = value;
			this.screen.rebuildSettingsWidgets();
		});
		this.screen.addContentWidget(this.searchBox);

		this.clampScrollOffset();
		this.applyScrollToControls();
	}

	private int getResetButtonWidth() {
		int textWidth = this.screen.method_64506()
				.method_1727(ModContentLanguage.get("gui.redstone-master.settings.reset"));
		return Math.max(RESET_BUTTON_MIN_WIDTH, textWidth + RESET_BUTTON_PADDING);
	}

	private class_4185 createResetButton(ModSetting setting, int x, int y, int width) {
		ModConfig config = ModConfig.get();
		class_4185 button = class_4185.method_46430(
						ModContentLanguage.translatable("gui.redstone-master.settings.reset"),
						b -> this.resetSetting(setting))
				.method_46434(x, y, width, ROW_HEIGHT)
				.method_46436(class_7919.method_47407(
						ModContentLanguage.translatable("gui.redstone-master.settings.reset.tooltip")))
				.method_46431();
		button.field_22763 = !config.isSettingAtDefault(setting);
		return button;
	}

	private void resetSetting(ModSetting setting) {
		ModConfig config = ModConfig.get();
		config.resetSetting(setting);
		config.save();
		switch (setting) {
			case PANEL_SCALE, HIGH_CONTRAST -> this.screen.rebuildAllWidgets();
			case AUTO_LANGUAGE, MANUAL_LANGUAGE -> this.onLanguageChanged();
			default -> this.screen.rebuildSettingsWidgets();
		}
	}

	private void openResetAllConfirm() {
		class_310 minecraft = class_310.method_1551();
		minecraft.method_1507(new class_410(
				confirmed -> {
					if (confirmed) {
						ModConfig.get().resetAllModSettings();
						ModConfig.get().save();
						ModContentLanguage.clearCache();
						this.screen.rebuildAllWidgets();
					}
					minecraft.method_1507(this.screen);
				},
				ModContentLanguage.translatable("gui.redstone-master.settings.reset_all.title"),
				ModContentLanguage.translatable("gui.redstone-master.settings.reset_all.message"),
				ModContentLanguage.translatable("gui.redstone-master.settings.reset_all.confirm"),
				ModContentLanguage.translatable("gui.redstone-master.settings.reset_all.cancel")
		));
	}

	private void onLanguageChanged() {
		ModContentLanguage.clearCache();
		this.screen.rebuildAllWidgets();
	}

	private class_4185 createValueButton(ModSetting setting, int x, int y, int width) {
		ModConfig config = ModConfig.get();
		return switch (setting) {
			case PANEL_SCALE -> class_4185.method_46430(
							this.getPanelScaleLabel(config),
							button -> {
								config.cyclePanelScale();
								this.screen.rebuildAllWidgets();
							})
					.method_46434(x, y, width, ROW_HEIGHT)
					.method_46431();
			case PAUSE_ON_OPEN -> class_4185.method_46430(
							this.getToggleLabel(config.pauseOnOpen),
							button -> {
								config.pauseOnOpen = !config.pauseOnOpen;
								config.save();
								this.screen.rebuildSettingsWidgets();
							})
					.method_46434(x, y, width, ROW_HEIGHT)
					.method_46436(class_7919.method_47407(
							ModContentLanguage.translatable("gui.redstone-master.settings.pause_on_open.tooltip")))
					.method_46431();
			case HIGH_CONTRAST -> class_4185.method_46430(
							this.getToggleLabel(config.highContrastBorders),
							button -> {
								config.highContrastBorders = !config.highContrastBorders;
								config.save();
								this.screen.rebuildAllWidgets();
							})
					.method_46434(x, y, width, ROW_HEIGHT)
					.method_46431();
			case AUTO_LANGUAGE -> class_4185.method_46430(
							this.getToggleLabel(config.autoLanguage),
							button -> {
								config.autoLanguage = !config.autoLanguage;
								if (!config.autoLanguage) {
									config.syncManualLanguageFromMinecraft();
								}
								config.save();
								this.onLanguageChanged();
							})
					.method_46434(x, y, width, ROW_HEIGHT)
					.method_46436(class_7919.method_47407(
							ModContentLanguage.translatable("gui.redstone-master.settings.auto_language.tooltip")))
					.method_46431();
			case REMEMBER_SESSION -> class_4185.method_46430(
							this.getToggleLabel(config.rememberSession),
							button -> {
								config.rememberSession = !config.rememberSession;
								if (config.rememberSession) {
									config.save();
								} else {
									ru.redstonemaster.config.ModSessionState.get().clear();
									this.screen.clearStoredSessionContent();
								}
								this.screen.rebuildSettingsWidgets();
							})
					.method_46434(x, y, width, ROW_HEIGHT)
					.method_46436(class_7919.method_47407(
							ModContentLanguage.translatable("gui.redstone-master.settings.remember_session.tooltip")))
					.method_46431();
			case MANUAL_LANGUAGE -> {
				class_2561 label = config.autoLanguage
						? ModContentLanguage.getMinecraftLanguageDisplayName()
						: ModContentLanguage.getLanguageDisplayName(config.manualLanguage);
				class_4185 button = class_4185.method_46430(label, b -> {
							if (!ModConfig.get().autoLanguage) {
								ModConfig.get().cycleManualLanguage();
								this.onLanguageChanged();
							}
						})
						.method_46434(x, y, width, ROW_HEIGHT)
						.method_46431();
				button.field_22763 = !config.autoLanguage;
				yield button;
			}
			case CLOSE_ON_REPEAT -> class_4185.method_46430(
							this.getToggleLabel(config.closeOnRepeatKey),
							button -> {
								config.closeOnRepeatKey = !config.closeOnRepeatKey;
								config.save();
								this.screen.rebuildSettingsWidgets();
							})
					.method_46434(x, y, width, ROW_HEIGHT)
					.method_46436(class_7919.method_47407(
							ModContentLanguage.translatable("gui.redstone-master.settings.close_on_repeat.tooltip")))
					.method_46431();
			case TUTORIAL_COLLAPSE_OTHERS -> class_4185.method_46430(
							this.getToggleLabel(config.tutorialCollapseOtherSections),
							button -> {
								config.tutorialCollapseOtherSections = !config.tutorialCollapseOtherSections;
								config.save();
								this.screen.rebuildSettingsWidgets();
							})
					.method_46434(x, y, width, ROW_HEIGHT)
					.method_46436(class_7919.method_47407(ModContentLanguage.translatable(
							"gui.redstone-master.settings.tutorial_collapse_other.tooltip")))
					.method_46431();
		};
	}

	private class_2561 getPanelScaleLabel(ModConfig config) {
		int percent = (int) Math.round(config.panelScale * 100);
		return ModContentLanguage.translatable("gui.redstone-master.settings.panel_scale.value", percent);
	}

	private class_2561 getToggleLabel(boolean enabled) {
		return ModContentLanguage.translatable(
				enabled ? "gui.redstone-master.settings.value.on" : "gui.redstone-master.settings.value.off"
		);
	}

	private int getDisclaimerHeight(int width) {
		return this.getDisclaimerLineCount(width) * this.screen.method_64506().field_2000;
	}

	private int getDisclaimerLineCount(int width) {
		return this.screen.method_64506()
				.method_1728(ModContentLanguage.translatable(DISCLAIMER_KEY), width)
				.size();
	}

	private int getSettingLineCount(ModSetting setting, int labelWidth) {
		String bulletName = "• " + ModContentLanguage.get(setting.getNameKey());
		return this.screen.method_64506().method_1728(class_2561.method_43470(bulletName), labelWidth).size();
	}

	private int getSettingRowHeight(int lineCount) {
		int textHeight = lineCount * this.screen.method_64506().field_2000;
		return Math.max(ROW_HEIGHT, textHeight);
	}

	private int getSettingButtonY(int rowY, int rowHeight) {
		return rowY + (rowHeight - ROW_HEIGHT) / 2;
	}

	private int getSettingLabelY(int rowY, int rowHeight, int lineCount) {
		int textHeight = lineCount * this.screen.method_64506().field_2000;
		return rowY + Math.max(0, (rowHeight - textHeight) / 2);
	}

	void renderLabels(class_332 graphics) {
		int labelX = this.screen.getContentX() + RedstoneMasterScreen.CONTENT_INNER_PADDING + 4;
		int innerListWidth = this.screen.getContentWidth() - RedstoneMasterScreen.CONTENT_INNER_PADDING * 2;
		int resetButtonWidth = this.getResetButtonWidth();
		int controlsWidth = resetButtonWidth + RESET_BUTTON_GAP
				+ Math.min(VALUE_BUTTON_WIDTH, Math.max(48, innerListWidth - resetButtonWidth - RESET_BUTTON_GAP - 80));
		int labelWidth = innerListWidth - controlsWidth - 12;
		int listTop = this.getListTop();
		int scrollBottom = this.getScrollableContentBottom();

		graphics.method_44379(
				this.screen.getContentX() + 1,
				listTop,
				this.screen.getContentX() + this.screen.getContentWidth() - 1,
				scrollBottom
		);

		int disclaimerWidth = this.screen.getContentWidth() - RedstoneMasterScreen.CONTENT_INNER_PADDING * 2;

		for (LayoutRow row : this.layoutRows) {
			if (row.isDisclaimer) {
				int drawY = row.y - this.scrollOffset;
				List<net.minecraft.class_5481> lines = this.screen.method_64506()
						.method_1728(ModContentLanguage.translatable(DISCLAIMER_KEY), disclaimerWidth);
				int lineY = drawY;
				for (var line : lines) {
					if (lineY + this.screen.method_64506().field_2000 >= listTop && lineY <= scrollBottom) {
						graphics.method_51430(this.screen.method_64506(), line, labelX, lineY, DISCLAIMER_COLOR, true);
					}
					lineY += this.screen.method_64506().field_2000;
				}
			} else if (row.isSection) {
				int drawY = row.y - this.scrollOffset;
				if (drawY + this.screen.method_64506().field_2000 >= listTop && drawY <= scrollBottom) {
					graphics.method_51439(
							this.screen.method_64506(),
							ModContentLanguage.translatable(row.sectionKey),
							labelX,
							drawY,
							SECTION_COLOR,
							true
					);
				}
			} else if (row.setting != null) {
				int drawY = row.y - this.scrollOffset;
				String bulletName = "• " + ModContentLanguage.get(row.setting.getNameKey());
				List<net.minecraft.class_5481> lines = this.screen.method_64506()
						.method_1728(class_2561.method_43470(bulletName), labelWidth);
				int lineY = this.getSettingLabelY(drawY, row.rowHeight, lines.size());
				for (var line : lines) {
					if (lineY + this.screen.method_64506().field_2000 >= listTop && lineY <= scrollBottom) {
						graphics.method_51430(this.screen.method_64506(), line, labelX, lineY, TEXT_COLOR, true);
					}
					lineY += this.screen.method_64506().field_2000;
				}
			}
		}

		graphics.method_44380();
	}

	boolean mouseScrolled(double scrollX, double scrollY) {
		int maxScroll = this.getMaxScroll();
		if (maxScroll <= 0) {
			return false;
		}
		this.scrollOffset = (int) Math.clamp(this.scrollOffset - scrollY * 12, 0, maxScroll);
		this.applyScrollToControls();
		return true;
	}

	private void applyScrollToControls() {
		int listTop = this.getListTop();
		int scrollBottom = this.getScrollableContentBottom();
		int settingIndex = 0;

		for (LayoutRow row : this.layoutRows) {
			if (row.setting == null) {
				continue;
			}
			int displayY = this.getSettingButtonY(row.y - this.scrollOffset, row.rowHeight);
			boolean visible = displayY >= listTop - 1 && displayY + ROW_HEIGHT <= scrollBottom + 1;
			if (settingIndex < this.valueButtons.size()) {
				class_4185 valueButton = this.valueButtons.get(settingIndex);
				valueButton.method_46419(displayY);
				valueButton.field_22764 = visible;
			}
			if (settingIndex < this.resetButtons.size()) {
				class_4185 resetButton = this.resetButtons.get(settingIndex);
				resetButton.method_46419(displayY);
				resetButton.field_22764 = visible;
			}
			settingIndex++;
		}
	}

	private void clampScrollOffset() {
		this.scrollOffset = (int) Math.clamp(this.scrollOffset, 0, this.getMaxScroll());
	}

	private int getMaxScroll() {
		return Math.max(0, this.getListContentHeight() - this.getListViewHeight());
	}

	int getSearchY() {
		return this.screen.getContentY() + RedstoneMasterScreen.CONTENT_INNER_PADDING;
	}

	int getSearchHeight() {
		return Math.max(SEARCH_HEIGHT, this.screen.method_64506().field_2000 + 10);
	}

	int getListTop() {
		return this.getSearchY() + this.getSearchHeight() + SEARCH_BOTTOM_GAP;
	}

	private int getContentBottom() {
		return this.screen.getContentY() + this.screen.getContentHeight() - RedstoneMasterScreen.CONTENT_INNER_PADDING;
	}

	private int getResetAllButtonY() {
		return this.getContentBottom() - ROW_HEIGHT;
	}

	private int getScrollableContentBottom() {
		return this.getResetAllButtonY() - RESET_ALL_GAP;
	}

	private int getListViewHeight() {
		return this.getScrollableContentBottom() - this.getListTop();
	}

	private int getListContentHeight() {
		if (this.layoutRows.isEmpty()) {
			return 0;
		}
		LayoutRow last = this.layoutRows.get(this.layoutRows.size() - 1);
		return last.y + last.rowHeight - this.getListTop();
	}

	int getContentClipTop() {
		return this.screen.getContentY() + 1;
	}

	int getContentClipBottom() {
		return this.getContentBottom();
	}

	int getScrollOffset() {
		return this.scrollOffset;
	}

	void setScrollOffset(int scrollOffset) {
		this.scrollOffset = Math.max(0, scrollOffset);
	}

	void dispose() {
		this.searchBox = null;
		this.resetAllButton = null;
		this.layoutRows.clear();
		this.valueButtons.clear();
		this.resetButtons.clear();
	}

	private static final class LayoutRow {
		private final boolean isSection;
		private final boolean isDisclaimer;
		private final String sectionKey;
		private final ModSetting setting;
		private final int y;
		private final int rowHeight;

		private LayoutRow(
				boolean isSection,
				boolean isDisclaimer,
				String sectionKey,
				ModSetting setting,
				int y,
				int rowHeight
		) {
			this.isSection = isSection;
			this.isDisclaimer = isDisclaimer;
			this.sectionKey = sectionKey;
			this.setting = setting;
			this.y = y;
			this.rowHeight = rowHeight;
		}

		static LayoutRow section(String sectionKey, int y) {
			return new LayoutRow(true, false, sectionKey, null, y, 0);
		}

		static LayoutRow disclaimer(int y, int rowHeight) {
			return new LayoutRow(false, true, null, null, y, rowHeight);
		}

		static LayoutRow setting(ModSetting setting, int y, int rowHeight) {
			return new LayoutRow(false, false, null, setting, y, rowHeight);
		}
	}
}
