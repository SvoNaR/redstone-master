package ru.redstonemaster.client.gui;

import ru.redstonemaster.client.gui.tutorial.TutorialCatalog;
import ru.redstonemaster.client.gui.tutorial.TutorialCatalog.FilteredSection;
import ru.redstonemaster.client.gui.tutorial.TutorialLesson;
import ru.redstonemaster.client.gui.tutorial.TutorialLessonProgress;
import ru.redstonemaster.client.gui.tutorial.TutorialSection;
import ru.redstonemaster.client.gui.tutorial.TutorialStudyTarget;
import ru.redstonemaster.client.gui.tutorial.TutorialTextures;
import ru.redstonemaster.client.video.PseudoVideoLayout;
import ru.redstonemaster.client.video.PseudoVideoRenderer;
import ru.redstonemaster.client.video.PseudoVideoSeekSlider;
import ru.redstonemaster.client.video.PseudoVideoService;
import ru.redstonemaster.config.ModConfig;
import ru.redstonemaster.config.ModContentLanguage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;

final class RedstoneMasterTutorialPanel {
	private static final String DISCLAIMER_KEY = "gui.redstone-master.tutorial.disclaimer";
	private static final String SECTIONS_HEADER_KEY = "gui.redstone-master.tutorial.sections_header";

	private static final int SEARCH_HEIGHT = 20;
	private static final int ROW_HEIGHT = 20;
	private static final int ROW_GAP = 2;
	private static final int SEARCH_LINE_GAP = 1;
	private static final int DISCLAIMER_GAP = 6;
	private static final int HEADER_GAP = 6;
	private static final int SECTIONS_HEADER_EXTRA_GAP_LINES = 1;
	private static final int SECTION_BLOCK_GAP = 6;
	private static final int SECTION_BLOCK_PADDING = 4;
	private static final int STUDY_BUTTON_MIN_WIDTH = 56;
	private static final int STUDY_BUTTON_PADDING = 8;
	private static final int ARROW_BUTTON_SIZE = 20;
	private static final int ARROW_TO_TITLE_GAP = 4;
	private static final int LESSON_EXTRA_INDENT = 6;
	private static final int LESSON_CHECKBOX_SIZE = 14;
	private static final int LESSON_CHECKBOX_GAP = 4;
	private static final int SECTION_PROGRESS_GAP = 8;
	private static final int IMAGE_GAP = 10;
	private static final String VIDEO_GOAL_HEADING_KEY = "gui.redstone-master.tutorial.video.goal_heading";
	private static final int VIDEO_GAP = 8;
	private static final int VIDEO_CONTROLS_HEIGHT = 20;
	private static final int VIDEO_CONTROLS_GAP = 0;
	private static final int VIDEO_AFTER_CONTROLS_GAP = 10;
	private static final int VIDEO_GOAL_HEADER_GAP = 4;
	private static final int VIDEO_PLAY_BUTTON_WIDTH = 28;
	private static final int VIDEO_FULLSCREEN_BUTTON_WIDTH = 28;
	private static final int COLLAPSE_ALL_GAP = 6;

	private static final int SECTION_COLOR = 0xFFE8C070;
	private static final int SECTION_TITLE_DOWN_OFFSET = 2;
	private static final int SECTION_SUMMARY_VERTICAL_PADDING = 1;
	private static final int LESSON_COLOR = 0xFFFFFFFF;
	private static final int TEXT_COLOR = 0xFFFFFFFF;
	private static final int HEADER_LABEL_COLOR = 0xFFE0E0E0;
	private static final int DISCLAIMER_COLOR = 0xFFBBBBBB;
	private static final int SOURCES_COLOR = 0xFFAAAAAA;
	private static final int EMPTY_COLOR = 0xFFBBBBBB;
	private static final int PROGRESS_COLOR = 0xFFBBBBBB;
	private static final int LESSON_CHECKMARK_COLOR = 0xFF55FF55;
	private static final int LINE_COLOR_NORMAL = 0xFF000000;
	private static final int LINE_COLOR_HIGH_CONTRAST = 0xFFFFFFFF;

	private final RedstoneMasterScreen screen;
	private class_342 searchBox;
	private String searchQuery = "";
	private int scrollOffset;
	private int savedListScrollOffset;
	private TutorialStudyTarget studyTarget;
	private final Set<String> expandedSections = new HashSet<>();
	private final List<LayoutRow> layoutRows = new ArrayList<>();
	private final List<class_4185> studyButtons = new ArrayList<>();
	private final List<class_4185> sectionToggleButtons = new ArrayList<>();
	private class_4185 backButton;
	private class_4185 collapseAllButton;
	private class_4185 videoPlayPauseButton;
	private class_4185 videoSeekBackButton;
	private class_4185 videoSeekForwardButton;
	private class_4185 videoFullscreenButton;
	private PseudoVideoSeekSlider videoSeekSlider;
	private String activeStudyVideoId = "";
	private boolean videoFullscreen;

	RedstoneMasterTutorialPanel(RedstoneMasterScreen screen) {
		this.screen = screen;
	}

	boolean isStudying() {
		return this.studyTarget != null;
	}

	void leaveTab() {
		this.exitVideoFullscreen();
		PseudoVideoService.get().release();
		this.activeStudyVideoId = "";
		this.studyTarget = null;
	}

	void resetToHome() {
		this.studyTarget = null;
		this.scrollOffset = 0;
		this.savedListScrollOffset = 0;
		this.expandedSections.clear();
	}

	/** Прокрутка списка разделов для сохранения сессии (не прокрутка страницы «Изучить»). */
	int getListScrollOffsetForPersistence() {
		return this.isStudying() ? this.savedListScrollOffset : this.scrollOffset;
	}

	void restoreExpandedSections(String csv) {
		this.expandedSections.clear();
		if (csv == null || csv.isBlank()) {
			return;
		}
		for (String part : csv.split(",")) {
			String id = part.trim();
			if (!id.isEmpty()) {
				this.expandedSections.add(id);
			}
		}
	}

	String getExpandedSectionsCsv() {
		return String.join(",", this.expandedSections);
	}

	int getScrollOffset() {
		return this.scrollOffset;
	}

	void setScrollOffset(int scrollOffset) {
		this.scrollOffset = Math.max(0, scrollOffset);
		this.updateLessonCompletionFromScroll();
	}

	void dispose() {
		PseudoVideoService.get().release();
		this.activeStudyVideoId = "";
		this.searchBox = null;
		this.backButton = null;
		this.collapseAllButton = null;
		this.videoPlayPauseButton = null;
		this.videoSeekBackButton = null;
		this.videoSeekForwardButton = null;
		this.videoFullscreenButton = null;
		this.videoSeekSlider = null;
		this.layoutRows.clear();
		this.studyButtons.clear();
		this.sectionToggleButtons.clear();
	}

	void rebuildWidgets() {
		this.layoutRows.clear();
		this.studyButtons.clear();
		this.sectionToggleButtons.clear();
		this.backButton = null;
		this.videoPlayPauseButton = null;
		this.videoSeekBackButton = null;
		this.videoSeekForwardButton = null;
		this.videoFullscreenButton = null;
		this.videoSeekSlider = null;

		int innerX = this.screen.getContentX() + RedstoneMasterScreen.CONTENT_INNER_PADDING;
		int innerWidth = this.screen.getContentWidth() - RedstoneMasterScreen.CONTENT_INNER_PADDING * 2;

		if (this.studyTarget != null) {
			this.rebuildStudyWidgets(innerX, innerWidth);
			return;
		}

		this.rebuildListWidgets(innerX, innerWidth);
	}

	private void rebuildStudyWidgets(int innerX, int innerWidth) {
		this.layoutRows.add(LayoutRow.studyBody(this.getListTop()));

		this.backButton = class_4185.method_46430(
						ModContentLanguage.translatable("gui.redstone-master.tutorial.back"),
						button -> this.closeStudy())
				.method_46434(innerX, this.getSearchY(), 80, this.getSearchHeight())
				.method_46431();
		this.screen.addContentWidget(this.backButton);

		StudyContent content = this.resolveStudyContent();
		String videoId = content != null && !content.videos().isEmpty() ? content.videos().getFirst() : "";
		if (!videoId.equals(this.activeStudyVideoId)) {
			this.activeStudyVideoId = videoId;
			if (videoId.isBlank()) {
				PseudoVideoService.get().release();
			} else {
				PseudoVideoService.get().activate(videoId);
			}
		}

		if (!videoId.isBlank()) {
			int seekBackWidth = this.getVideoSeekButtonWidth("gui.redstone-master.tutorial.video.seek_back");
			int seekForwardWidth = this.getVideoSeekButtonWidth("gui.redstone-master.tutorial.video.seek_forward");
			this.videoSeekBackButton = class_4185.method_46430(
							ModContentLanguage.translatable("gui.redstone-master.tutorial.video.seek_back"),
							button -> PseudoVideoService.get().seekBackward())
					.method_46434(innerX, 0, seekBackWidth, VIDEO_CONTROLS_HEIGHT)
					.method_46431();
			this.videoPlayPauseButton = class_4185.method_46430(
							this.getVideoPlayPauseLabel(),
							button -> {
								PseudoVideoService.get().togglePlayPause();
								button.method_25355(this.getVideoPlayPauseLabel());
							})
					.method_46434(innerX, 0, VIDEO_PLAY_BUTTON_WIDTH, VIDEO_CONTROLS_HEIGHT)
					.method_46431();
			this.videoSeekForwardButton = class_4185.method_46430(
							ModContentLanguage.translatable("gui.redstone-master.tutorial.video.seek_forward"),
							button -> PseudoVideoService.get().seekForward())
					.method_46434(innerX, 0, seekForwardWidth, VIDEO_CONTROLS_HEIGHT)
					.method_46431();
			this.screen.addContentWidget(this.videoSeekBackButton);
			this.screen.addContentWidget(this.videoPlayPauseButton);
			this.screen.addContentWidget(this.videoSeekForwardButton);

			this.videoFullscreenButton = class_4185.method_46430(
							this.getVideoFullscreenLabel(),
							button -> this.toggleVideoFullscreen())
					.method_46434(innerX, 0, VIDEO_FULLSCREEN_BUTTON_WIDTH, VIDEO_CONTROLS_HEIGHT)
					.method_46431();
			this.screen.addContentWidget(this.videoFullscreenButton);

			this.videoSeekSlider = new PseudoVideoSeekSlider(0, 0, 100, PseudoVideoLayout.SLIDER_INNER_HEIGHT);
			this.screen.addContentWidget(this.videoSeekSlider);
			this.setVideoControlsVisible(false);
			this.layoutStudyVideoControls();
		}

		this.clampScrollOffset();
		this.updateLessonCompletionFromScroll();
	}

	private class_2561 getVideoPlayPauseLabel() {
		return PseudoVideoService.get().isPlaying()
				? ModContentLanguage.translatable("gui.redstone-master.tutorial.video.pause")
				: ModContentLanguage.translatable("gui.redstone-master.tutorial.video.play");
	}

	private int getVideoSeekButtonWidth(String key) {
		return this.screen.method_64506().method_1727(ModContentLanguage.get(key)) + STUDY_BUTTON_PADDING;
	}

	private class_2561 getVideoFullscreenLabel() {
		return ModContentLanguage.translatable(
				this.videoFullscreen
						? "gui.redstone-master.tutorial.video.exit_fullscreen"
						: "gui.redstone-master.tutorial.video.fullscreen"
		);
	}

	private int getVideoTimeBlockWidth() {
		int sampleWidth = Math.max(
				this.screen.method_64506().method_1727("00:00/00:00"),
				this.screen.method_64506().method_1727(PseudoVideoService.get().getPlaybackTimeLabel())
		);
		return sampleWidth + PseudoVideoLayout.CONTROLS_SIDE_PADDING * 2;
	}

	private int getVideoControlsInnerWidth() {
		return this.getVideoTimeBlockWidth()
				+ this.getVideoSeekBackWidth()
				+ VIDEO_PLAY_BUTTON_WIDTH
				+ this.getVideoSeekForwardWidth()
				+ VIDEO_FULLSCREEN_BUTTON_WIDTH;
	}

	boolean isVideoFullscreen() {
		return this.videoFullscreen;
	}

	boolean handleVideoFullscreenEscape() {
		if (!this.videoFullscreen || !this.hasActiveStudyVideo()) {
			return false;
		}
		this.exitVideoFullscreen();
		return true;
	}

	private void toggleVideoFullscreen() {
		this.videoFullscreen = !this.videoFullscreen;
		if (this.videoFullscreenButton != null) {
			this.videoFullscreenButton.method_25355(this.getVideoFullscreenLabel());
		}
		this.screen.applyTutorialVideoFullscreenChrome(this.videoFullscreen);
		this.layoutStudyVideoControls();
	}

	private void exitVideoFullscreen() {
		if (!this.videoFullscreen) {
			return;
		}
		this.videoFullscreen = false;
		if (this.videoFullscreenButton != null) {
			this.videoFullscreenButton.method_25355(this.getVideoFullscreenLabel());
		}
		this.screen.applyTutorialVideoFullscreenChrome(false);
	}

	private int getVideoSeekBackWidth() {
		return this.getVideoSeekButtonWidth("gui.redstone-master.tutorial.video.seek_back");
	}

	private int getVideoSeekForwardWidth() {
		return this.getVideoSeekButtonWidth("gui.redstone-master.tutorial.video.seek_forward");
	}

	private PseudoVideoLayout computeVideoLayout(int embeddedContentTop, int textX, int textWidth) {
		int timeBlockWidth = this.getVideoTimeBlockWidth();
		int seekBackWidth = this.getVideoSeekBackWidth();
		int seekForwardWidth = this.getVideoSeekForwardWidth();
		if (this.videoFullscreen) {
			return PseudoVideoLayout.windowFullscreen(
					this.screen.getScreenWidth(),
					this.screen.getScreenHeight(),
					VIDEO_CONTROLS_HEIGHT,
					this.getVideoControlsInnerWidth(),
					timeBlockWidth,
					VIDEO_FULLSCREEN_BUTTON_WIDTH,
					seekBackWidth,
					VIDEO_PLAY_BUTTON_WIDTH,
					seekForwardWidth,
					this.screen.method_64506()
			);
		}
		return PseudoVideoLayout.embedded(
				embeddedContentTop,
				textX,
				textWidth,
				VIDEO_CONTROLS_HEIGHT,
				this.getVideoControlsInnerWidth(),
				timeBlockWidth,
				VIDEO_FULLSCREEN_BUTTON_WIDTH,
				seekBackWidth,
				VIDEO_PLAY_BUTTON_WIDTH,
				seekForwardWidth,
				this.screen.method_64506()
		);
	}

	boolean isVideoControlWidget(Object widget) {
		return widget == this.videoPlayPauseButton
				|| widget == this.videoSeekBackButton
				|| widget == this.videoSeekForwardButton
				|| widget == this.videoFullscreenButton
				|| widget == this.videoSeekSlider;
	}

	void applyStudyChromeVisible(boolean visible) {
		if (this.searchBox != null) {
			this.searchBox.field_22764 = visible;
		}
		if (this.backButton != null) {
			this.backButton.field_22764 = visible;
		}
		if (this.collapseAllButton != null) {
			this.collapseAllButton.field_22764 = visible;
		}
		for (class_4185 button : this.sectionToggleButtons) {
			button.field_22764 = visible;
		}
		for (class_4185 button : this.studyButtons) {
			button.field_22764 = visible;
		}
	}

	void restoreAfterVideoFullscreen() {
		if (this.isStudying()) {
			this.applyStudyChromeVisible(true);
			this.layoutStudyVideoControls();
			return;
		}
		this.applyStudyChromeVisible(true);
		this.applyScrollToControls();
	}

	private int getEmbeddedVideoContentTop(StudyContent content, int textWidth) {
		int y = this.getListTop() - this.scrollOffset;
		y += this.screen.method_64506()
						.method_1728(class_2561.method_43470(content.title()).method_27692(net.minecraft.class_124.field_1067), textWidth)
						.size()
				* this.screen.method_64506().field_2000
				+ 4;
		if (!content.videos().isEmpty()) {
			StudyBodyParts bodyParts = this.splitStudyBodyForVideo(content.body());
			if (this.hasStudyGoalBeforeVideo(content.body(), bodyParts)) {
				y += this.measureStudyGoalBeforeVideoHeight(bodyParts.goalParagraph(), textWidth);
			} else {
				y += VIDEO_GAP;
			}
		}
		return y;
	}

	private boolean hasStudyGoalBeforeVideo(String body, StudyBodyParts bodyParts) {
		return body.startsWith(ModContentLanguage.get(VIDEO_GOAL_HEADING_KEY));
	}

	private StudyBodyParts splitStudyBodyForVideo(String body) {
		String goalHeading = ModContentLanguage.get(VIDEO_GOAL_HEADING_KEY);
		if (!body.startsWith(goalHeading)) {
			return new StudyBodyParts("", body);
		}
		String rest = body.substring(goalHeading.length());
		if (rest.startsWith("\r\n")) {
			rest = rest.substring(2);
		} else if (rest.startsWith("\n")) {
			rest = rest.substring(1);
		}
		int sectionBreak = rest.indexOf("\n\n");
		if (sectionBreak >= 0) {
			return new StudyBodyParts(rest.substring(0, sectionBreak).trim(), rest.substring(sectionBreak + 2));
		}
		return new StudyBodyParts(rest.trim(), "");
	}

	private int measureStudyGoalBeforeVideoHeight(String goalParagraph, int textWidth) {
		int height = this.screen.method_64506()
						.method_1728(
								class_2561.method_43470(ModContentLanguage.get(VIDEO_GOAL_HEADING_KEY))
										.method_27692(net.minecraft.class_124.field_1067),
								textWidth
						)
						.size()
				* this.screen.method_64506().field_2000
				+ VIDEO_GOAL_HEADER_GAP;
		if (!goalParagraph.isBlank()) {
			height += this.screen.method_64506().method_1728(class_2561.method_43470(goalParagraph), textWidth).size()
					* this.screen.method_64506().field_2000;
		}
		return height + VIDEO_GAP;
	}

	private int renderStudyGoalBeforeVideo(
			class_332 graphics,
			int textX,
			int textWidth,
			int y,
			int listTop,
			int contentBottom,
			String goalParagraph
	) {
		for (var line : this.screen.method_64506()
				.method_1728(
						class_2561.method_43470(ModContentLanguage.get(VIDEO_GOAL_HEADING_KEY))
								.method_27692(net.minecraft.class_124.field_1067),
						textWidth
				)) {
			if (y + this.screen.method_64506().field_2000 >= listTop && y <= contentBottom) {
				graphics.method_51430(this.screen.method_64506(), line, textX, y, SECTION_COLOR, true);
			}
			y += this.screen.method_64506().field_2000;
		}
		y += VIDEO_GOAL_HEADER_GAP;
		if (!goalParagraph.isBlank()) {
			for (var line : this.screen.method_64506().method_1728(class_2561.method_43470(goalParagraph), textWidth)) {
				if (y + this.screen.method_64506().field_2000 >= listTop && y <= contentBottom) {
					graphics.method_51430(this.screen.method_64506(), line, textX, y, TEXT_COLOR, true);
				}
				y += this.screen.method_64506().field_2000;
			}
		}
		return y + VIDEO_GAP;
	}

	private boolean hasActiveStudyVideo() {
		return this.activeStudyVideoId != null && !this.activeStudyVideoId.isBlank();
	}

	private void rebuildListWidgets(int innerX, int innerWidth) {
		int studyButtonWidth = this.getStudyButtonWidth();
		int lessonControlsWidth = this.getLessonControlsWidth(studyButtonWidth);
		int blockInnerX = innerX + SECTION_BLOCK_PADDING;
		int blockInnerWidth = innerWidth - SECTION_BLOCK_PADDING * 2;
		int progressReservedWidth = this.getSectionProgressReservedWidth();
		int y = this.getListTop();

		int disclaimerHeight = this.getDisclaimerHeight(innerWidth);
		this.layoutRows.add(LayoutRow.disclaimer(y, disclaimerHeight));
		y += disclaimerHeight + DISCLAIMER_GAP + this.getSectionsHeaderTopGap();

		int headerHeight = this.screen.method_64506().field_2000;
		this.layoutRows.add(LayoutRow.sectionsHeader(y, headerHeight));
		y += headerHeight + HEADER_GAP;

		List<FilteredSection> filtered = TutorialCatalog.filter(this.searchQuery);

		for (FilteredSection entry : filtered) {
			TutorialSection section = entry.section();
			boolean expanded = entry.forceExpanded() || this.expandedSections.contains(section.id());
			int blockTop = y;

			y += SECTION_BLOCK_PADDING;
			int sectionRowY = y;
			int sectionTitleMaxWidth = blockInnerWidth - ARROW_BUTTON_SIZE - ARROW_TO_TITLE_GAP - progressReservedWidth - 4;
			int sectionTitleLines = this.screen.method_64506()
					.method_1728(class_2561.method_43470(section.title()), sectionTitleMaxWidth)
					.size();
			int sectionRowHeight = Math.max(
					ROW_HEIGHT,
					sectionTitleLines * this.screen.method_64506().field_2000
			);

			class_4185 arrowButton = class_4185.method_46430(
							this.getExpandArrowLabel(expanded),
							button -> this.toggleSection(section.id()))
					.method_46434(blockInnerX, sectionRowY, ARROW_BUTTON_SIZE, ROW_HEIGHT)
					.method_46431();
			this.sectionToggleButtons.add(arrowButton);
			this.screen.addContentWidget(arrowButton);

			this.layoutRows.add(LayoutRow.sectionHeader(section.id(), section.title(), sectionRowY, sectionRowHeight));
			y += sectionRowHeight + ROW_GAP;

			if (expanded) {
				String summary = section.summary();
				if (summary != null && !summary.isBlank()) {
					int lineHeight = this.screen.method_64506().field_2000;
					int summaryLineCount = this.screen.method_64506()
							.method_1728(class_2561.method_43470(summary), sectionTitleMaxWidth)
							.size();
					int summaryHeight = summaryLineCount * lineHeight + SECTION_SUMMARY_VERTICAL_PADDING * 2;
					this.layoutRows.add(LayoutRow.sectionSummary(summary, y, summaryHeight));
					y += summaryHeight + ROW_GAP;
				}

				int lessonX = blockInnerX + ARROW_BUTTON_SIZE + ARROW_TO_TITLE_GAP + LESSON_EXTRA_INDENT;
				int lessonStudyX = blockInnerX + blockInnerWidth - lessonControlsWidth;
				for (TutorialLesson lesson : entry.lessons()) {
					int lessonRowY = y;
					this.layoutRows.add(LayoutRow.lesson(section.id(), lesson.id(), lesson.title(), lessonRowY, ROW_HEIGHT));

					class_4185 lessonStudy = class_4185.method_46430(
									ModContentLanguage.translatable("gui.redstone-master.tutorial.study"),
									button -> this.openStudy(TutorialStudyTarget.lesson(section.id(), lesson.id())))
							.method_46434(lessonStudyX + LESSON_CHECKBOX_SIZE + LESSON_CHECKBOX_GAP, lessonRowY, studyButtonWidth, ROW_HEIGHT)
							.method_46431();
					this.studyButtons.add(lessonStudy);
					this.screen.addContentWidget(lessonStudy);
					y += ROW_HEIGHT + ROW_GAP;
				}
			}

			y += SECTION_BLOCK_PADDING;
			int blockHeight = y - blockTop;
			this.layoutRows.add(LayoutRow.sectionBlock(blockTop, blockHeight));
			y += SECTION_BLOCK_GAP;
		}

		if (filtered.isEmpty()) {
			this.layoutRows.add(LayoutRow.empty(y));
		}

		this.collapseAllButton = class_4185.method_46430(
						ModContentLanguage.translatable("gui.redstone-master.tutorial.collapse_all"),
						button -> this.collapseAllSections())
				.method_46434(innerX, this.getCollapseAllButtonY(), innerWidth, ROW_HEIGHT)
				.method_46431();
		this.collapseAllButton.field_22763 = !this.expandedSections.isEmpty();
		this.screen.addContentWidget(this.collapseAllButton);

		this.searchBox = new class_342(
				this.screen.method_64506(),
				innerX,
				this.getSearchY(),
				innerWidth,
				this.getSearchHeight(),
				ModContentLanguage.translatable("gui.redstone-master.tutorial.search_hint")
		);
		this.searchBox.method_1880(64);
		this.searchBox.method_47404(ModContentLanguage.translatable("gui.redstone-master.tutorial.search_hint"));
		this.searchBox.method_1852(this.searchQuery);
		this.searchBox.method_1863(value -> {
			this.searchQuery = value;
			this.scrollOffset = 0;
			this.screen.rebuildTutorialWidgets();
		});
		this.screen.addContentWidget(this.searchBox);

		this.clampScrollOffset();
		this.applyScrollToControls();
	}

	private int getDisclaimerHeight(int width) {
		return this.screen.method_64506()
				.method_1728(ModContentLanguage.translatable(DISCLAIMER_KEY), width)
				.size() * this.screen.method_64506().field_2000;
	}

	private class_2561 getExpandArrowLabel(boolean expanded) {
		return class_2561.method_43470(expanded ? "\u25BC" : "\u25C0");
	}

	private void toggleSection(String sectionId) {
		if (this.expandedSections.contains(sectionId)) {
			this.expandedSections.remove(sectionId);
		} else {
			if (ModConfig.get().tutorialCollapseOtherSections) {
				this.expandedSections.clear();
			}
			this.expandedSections.add(sectionId);
		}
		this.screen.rebuildTutorialWidgets();
	}

	private void collapseAllSections() {
		if (this.expandedSections.isEmpty()) {
			return;
		}
		this.expandedSections.clear();
		this.screen.rebuildTutorialWidgets();
	}

	private void openStudy(TutorialStudyTarget target) {
		if (this.studyTarget == null) {
			this.screen.onNavigationPointReached();
		}
		if (ModConfig.get().rememberSession) {
			this.savedListScrollOffset = this.scrollOffset;
		}
		this.studyTarget = target;
		this.scrollOffset = 0;
		this.screen.rebuildTutorialWidgets();
		this.screen.onNavigationPointReached();
	}

	private void closeStudy() {
		if (this.studyTarget == null) {
			return;
		}
		this.exitVideoFullscreen();
		PseudoVideoService.get().release();
		this.activeStudyVideoId = "";
		this.studyTarget = null;
		if (ModConfig.get().rememberSession) {
			this.scrollOffset = this.savedListScrollOffset;
		} else {
			this.scrollOffset = 0;
		}
		this.screen.rebuildTutorialWidgets();
		this.screen.onNavigationPointReached();
	}

	void restoreNavigationState(
			@org.jetbrains.annotations.Nullable TutorialStudyTarget target,
			int scrollOffset,
			int savedListScrollOffset
	) {
		this.studyTarget = target;
		this.scrollOffset = Math.max(0, scrollOffset);
		this.savedListScrollOffset = Math.max(0, savedListScrollOffset);
	}

	int getSavedListScrollOffset() {
		return this.savedListScrollOffset;
	}

	@org.jetbrains.annotations.Nullable
	TutorialStudyTarget getStudyTargetForNavigation() {
		return this.studyTarget;
	}

	boolean isValidStudyTarget(TutorialStudyTarget target) {
		TutorialCatalog.ensureLoaded();
		return switch (target) {
			case TutorialStudyTarget.SectionTarget section ->
					TutorialCatalog.findSection(section.sectionId()) != null;
			case TutorialStudyTarget.LessonTarget lesson ->
					TutorialCatalog.findLesson(lesson.sectionId(), lesson.lessonId()) != null;
		};
	}

	private int getStudyButtonWidth() {
		int textWidth = this.screen.method_64506()
				.method_1727(ModContentLanguage.get("gui.redstone-master.tutorial.study"));
		return Math.max(STUDY_BUTTON_MIN_WIDTH, textWidth + STUDY_BUTTON_PADDING);
	}

	private int getLessonControlsWidth(int studyButtonWidth) {
		return LESSON_CHECKBOX_SIZE + LESSON_CHECKBOX_GAP + studyButtonWidth;
	}

	private int getSectionProgressReservedWidth() {
		return this.screen.method_64506().method_1727("99 / 99") + SECTION_PROGRESS_GAP;
	}

	private String formatSectionProgress(String sectionId) {
		return TutorialLessonProgress.countCompleted(sectionId)
				+ " / "
				+ TutorialLessonProgress.countLessons(sectionId);
	}

	private void updateLessonCompletionFromScroll() {
		if (!(this.studyTarget instanceof TutorialStudyTarget.LessonTarget target)) {
			return;
		}
		int maxScroll = this.getMaxScroll();
		if (maxScroll <= 0 || this.scrollOffset >= maxScroll) {
			TutorialLessonProgress.markCompleted(target.sectionId(), target.lessonId());
		}
	}

	private void renderLessonCheckbox(
			class_332 graphics,
			int x,
			int y,
			boolean completed,
			int listTop,
			int contentBottom,
			int lineColor
	) {
		int boxY = y + (ROW_HEIGHT - LESSON_CHECKBOX_SIZE) / 2;
		if (boxY + LESSON_CHECKBOX_SIZE < listTop || boxY > contentBottom) {
			return;
		}
		graphics.method_73198(x, boxY, LESSON_CHECKBOX_SIZE, LESSON_CHECKBOX_SIZE, lineColor);
		if (completed) {
			String mark = "\u2713";
			int markX = x + (LESSON_CHECKBOX_SIZE - this.screen.method_64506().method_1727(mark)) / 2;
			int markY = boxY + (LESSON_CHECKBOX_SIZE - this.screen.method_64506().field_2000) / 2;
			graphics.method_51433(this.screen.method_64506(), mark, markX, markY, LESSON_CHECKMARK_COLOR, true);
		}
	}

	private int getLineColor() {
		return ModConfig.get().highContrastBorders ? LINE_COLOR_HIGH_CONTRAST : LINE_COLOR_NORMAL;
	}

	boolean mouseScrolled(double scrollX, double scrollY) {
		if (this.videoFullscreen) {
			return true;
		}
		int maxScroll = this.getMaxScroll();
		if (maxScroll <= 0) {
			return false;
		}
		this.scrollOffset = (int) Math.clamp(this.scrollOffset - scrollY * 12, 0, maxScroll);
		this.updateLessonCompletionFromScroll();
		if (this.isStudying()) {
			this.layoutStudyVideoControls();
		} else {
			this.applyScrollToControls();
		}
		return true;
	}

	void render(class_332 graphics) {
		int listTop = this.getListTop();
		int contentBottom = this.getScrollableContentBottom();
		int innerX = this.screen.getContentX() + RedstoneMasterScreen.CONTENT_INNER_PADDING;
		int innerWidth = this.screen.getContentWidth() - RedstoneMasterScreen.CONTENT_INNER_PADDING * 2;
		int textX = innerX + 2;
		int textWidth = innerWidth - 4;

		graphics.method_44379(
				this.screen.getContentX() + 1,
				listTop,
				this.screen.getContentX() + this.screen.getContentWidth() - 1,
				contentBottom
		);

		if (this.studyTarget != null) {
			this.renderStudyContent(graphics, innerX, textX, textWidth, listTop, contentBottom);
		} else {
			this.renderListContent(graphics, innerX, innerWidth, textX, textWidth, listTop, contentBottom);
		}

		graphics.method_44380();
	}

	void renderVideoFullscreenOverlay(class_332 graphics) {
		if (!this.videoFullscreen || !this.hasActiveStudyVideo()) {
			return;
		}
		PseudoVideoLayout layout = this.computeVideoLayout(0, 0, 0);
		PseudoVideoRenderer.renderPlayer(
				graphics,
				this.screen.method_64506(),
				layout,
				0,
				this.screen.getScreenHeight(),
				this.getLineColor(),
				true
		);
	}

	private void renderStudyContent(
			class_332 graphics,
			int innerX,
			int textX,
			int textWidth,
			int listTop,
			int contentBottom
	) {
		StudyContent content = this.resolveStudyContent();
		if (content == null) {
			return;
		}

		boolean hasVideo = !content.videos().isEmpty();
		StudyBodyParts bodyParts = hasVideo ? this.splitStudyBodyForVideo(content.body()) : new StudyBodyParts("", content.body());
		String bodyAfterVideo = hasVideo ? bodyParts.remainingBody() : content.body();
		int y = this.getListTop() - this.scrollOffset;
		for (var line : this.screen.method_64506()
				.method_1728(class_2561.method_43470(content.title()).method_27692(net.minecraft.class_124.field_1067), textWidth)) {
			if (y + this.screen.method_64506().field_2000 >= listTop && y <= contentBottom) {
				graphics.method_51430(this.screen.method_64506(), line, textX, y, SECTION_COLOR, true);
			}
			y += this.screen.method_64506().field_2000;
		}
		y += 4;

		if (hasVideo && this.hasStudyGoalBeforeVideo(content.body(), bodyParts)) {
			y = this.renderStudyGoalBeforeVideo(graphics, textX, textWidth, y, listTop, contentBottom, bodyParts.goalParagraph());
		}

		if (hasVideo && !this.videoFullscreen) {
			if (!this.hasStudyGoalBeforeVideo(content.body(), bodyParts)) {
				y += VIDEO_GAP;
			}
			int lineColor = this.getLineColor();
			PseudoVideoLayout layout = this.computeVideoLayout(y, textX, textWidth);
			PseudoVideoRenderer.renderPlayer(
					graphics,
					this.screen.method_64506(),
					layout,
					listTop,
					contentBottom,
					lineColor,
					true
			);
			y = layout.controlsBlockTop() + layout.controlsBlockHeight() + VIDEO_AFTER_CONTROLS_GAP;
		}

		if (!bodyAfterVideo.isBlank()) {
			for (var line : this.screen.method_64506().method_1728(class_2561.method_43470(bodyAfterVideo), textWidth)) {
				if (y + this.screen.method_64506().field_2000 >= listTop && y <= contentBottom) {
					graphics.method_51430(this.screen.method_64506(), line, textX, y, TEXT_COLOR, true);
				}
				y += this.screen.method_64506().field_2000;
			}
		}
		y += IMAGE_GAP;

		y = TutorialTextures.renderImages(
				graphics,
				this.screen.method_64506(),
				content.images(),
				textX,
				y,
				textWidth,
				listTop,
				contentBottom,
				IMAGE_GAP
		);

		y += 4;
		if (content.sources() != null && !content.sources().isBlank()) {
			for (var line : this.screen.method_64506().method_1728(class_2561.method_43470(content.sources()), textWidth)) {
				if (y + this.screen.method_64506().field_2000 >= listTop && y <= contentBottom) {
					graphics.method_51430(this.screen.method_64506(), line, textX, y, SOURCES_COLOR, true);
				}
				y += this.screen.method_64506().field_2000;
			}
		}
	}

	private StudyContent resolveStudyContent() {
		if (this.studyTarget instanceof TutorialStudyTarget.SectionTarget sectionTarget) {
			TutorialSection section = TutorialCatalog.findSection(sectionTarget.sectionId());
			if (section == null) {
				return null;
			}
			return new StudyContent(section.title(), section.summary(), section.sources(), section.imagePaths(), List.of());
		}
		if (this.studyTarget instanceof TutorialStudyTarget.LessonTarget lessonTarget) {
			TutorialLesson lesson = TutorialCatalog.findLesson(lessonTarget.sectionId(), lessonTarget.lessonId());
			TutorialSection section = TutorialCatalog.findSection(lessonTarget.sectionId());
			if (lesson == null) {
				return null;
			}
			String sources = section != null ? section.sources() : "";
			return new StudyContent(lesson.title(), lesson.body(), sources, lesson.imagePaths(), lesson.videoIds());
		}
		return null;
	}

	private void renderListContent(
			class_332 graphics,
			int innerX,
			int innerWidth,
			int textX,
			int textWidth,
			int listTop,
			int contentBottom
	) {
		int lineColor = this.getLineColor();
		int studyButtonWidth = this.getStudyButtonWidth();
		int lessonControlsWidth = this.getLessonControlsWidth(studyButtonWidth);
		int progressReservedWidth = this.getSectionProgressReservedWidth();
		int blockInnerX = innerX + SECTION_BLOCK_PADDING;
		int blockInnerWidth = innerWidth - SECTION_BLOCK_PADDING * 2;
		int sectionTitleX = blockInnerX + ARROW_BUTTON_SIZE + ARROW_TO_TITLE_GAP;
		int sectionTitleMaxWidth = blockInnerWidth - ARROW_BUTTON_SIZE - ARROW_TO_TITLE_GAP - progressReservedWidth - 4;
		int sectionProgressRight = innerX + innerWidth - SECTION_BLOCK_PADDING;
		int lessonX = sectionTitleX + LESSON_EXTRA_INDENT;
		int lessonCheckboxX = blockInnerX + blockInnerWidth - lessonControlsWidth;

		for (LayoutRow row : this.layoutRows) {
			int drawY = row.y - this.scrollOffset;

			if (row.isSectionBlock) {
				if (drawY + row.rowHeight >= listTop && drawY <= contentBottom) {
					graphics.method_73198(innerX, drawY, innerWidth, row.rowHeight, lineColor);
				}
				continue;
			}

			if (row.isDisclaimer) {
				int lineY = drawY;
				for (var line : this.screen.method_64506()
						.method_1728(ModContentLanguage.translatable(DISCLAIMER_KEY), textWidth)) {
					if (lineY + this.screen.method_64506().field_2000 >= listTop && lineY <= contentBottom) {
						graphics.method_51430(this.screen.method_64506(), line, textX, lineY, DISCLAIMER_COLOR, true);
					}
					lineY += this.screen.method_64506().field_2000;
				}
			} else if (row.isSectionsHeader) {
				if (drawY + this.screen.method_64506().field_2000 >= listTop && drawY <= contentBottom) {
					graphics.method_51439(
							this.screen.method_64506(),
							ModContentLanguage.translatable(SECTIONS_HEADER_KEY),
							textX,
							drawY,
							HEADER_LABEL_COLOR,
							true
					);
				}
			} else if (row.isEmpty) {
				if (drawY + this.screen.method_64506().field_2000 >= listTop && drawY <= contentBottom) {
					graphics.method_51439(
							this.screen.method_64506(),
							ModContentLanguage.translatable("gui.redstone-master.tutorial.no_results"),
							textX,
							drawY,
							EMPTY_COLOR,
							true
					);
				}
			} else if (row.sectionTitle != null) {
				var titleLines = this.screen.method_64506()
						.method_1728(class_2561.method_43470(row.sectionTitle), sectionTitleMaxWidth);
				int textHeight = titleLines.size() * this.screen.method_64506().field_2000;
				int textY = drawY + Math.max(0, (row.rowHeight - textHeight) / 2) + SECTION_TITLE_DOWN_OFFSET;
				for (var line : titleLines) {
					if (textY + this.screen.method_64506().field_2000 >= listTop && textY <= contentBottom) {
						graphics.method_51430(this.screen.method_64506(), line, sectionTitleX, textY, SECTION_COLOR, true);
					}
					textY += this.screen.method_64506().field_2000;
				}
				if (row.sectionId != null) {
					String progress = this.formatSectionProgress(row.sectionId);
					int progressWidth = this.screen.method_64506().method_1727(progress);
					int progressY = drawY + (row.rowHeight - this.screen.method_64506().field_2000) / 2 + SECTION_TITLE_DOWN_OFFSET;
					if (progressY + this.screen.method_64506().field_2000 >= listTop && progressY <= contentBottom) {
						graphics.method_51433(
								this.screen.method_64506(),
								progress,
								sectionProgressRight - progressWidth,
								progressY,
								PROGRESS_COLOR,
								true
						);
					}
				}
			} else if (row.sectionSummary != null) {
				int lineY = drawY + SECTION_SUMMARY_VERTICAL_PADDING;
				for (var line : this.screen.method_64506()
						.method_1728(class_2561.method_43470(row.sectionSummary), sectionTitleMaxWidth)) {
					if (lineY + this.screen.method_64506().field_2000 >= listTop && lineY <= contentBottom) {
						graphics.method_51430(this.screen.method_64506(), line, sectionTitleX, lineY, DISCLAIMER_COLOR, true);
					}
					lineY += this.screen.method_64506().field_2000;
				}
			} else if (row.lessonTitle != null) {
				if (drawY + this.screen.method_64506().field_2000 >= listTop && drawY <= contentBottom) {
					graphics.method_51439(
							this.screen.method_64506(),
							class_2561.method_43470("• " + row.lessonTitle),
							lessonX,
							drawY + (ROW_HEIGHT - this.screen.method_64506().field_2000) / 2,
							LESSON_COLOR,
							true
					);
				}
				if (row.sectionId != null && row.lessonId != null) {
					this.renderLessonCheckbox(
							graphics,
							lessonCheckboxX,
							drawY,
							TutorialLessonProgress.isCompleted(row.sectionId, row.lessonId),
							listTop,
							contentBottom,
							lineColor
					);
				}
			}
		}
	}

	void layoutStudyVideoControls() {
		if (!this.isStudying() || !this.hasActiveStudyVideo()) {
			return;
		}
		int innerX = this.screen.getContentX() + RedstoneMasterScreen.CONTENT_INNER_PADDING;
		int innerWidth = this.screen.getContentWidth() - RedstoneMasterScreen.CONTENT_INNER_PADDING * 2;
		int textWidth = innerWidth - 4;
		this.layoutStudyVideoControls(innerX, textWidth, this.getListTop(), this.getScrollableContentBottom());
	}

	private void layoutStudyVideoControls(int innerX, int textWidth, int listTop, int contentBottom) {
		if (!this.hasActiveStudyVideo()
				|| this.videoPlayPauseButton == null
				|| this.videoSeekBackButton == null
				|| this.videoSeekForwardButton == null
				|| this.videoFullscreenButton == null
				|| this.videoSeekSlider == null) {
			return;
		}

		StudyContent content = this.resolveStudyContent();
		if (content == null) {
			return;
		}

		int textX = innerX + 2;
		int embeddedTop = this.getEmbeddedVideoContentTop(content, textWidth);
		PseudoVideoLayout layout = this.computeVideoLayout(embeddedTop, textX, textWidth);
		int clipTop = this.videoFullscreen ? 0 : listTop;
		int clipBottom = this.videoFullscreen ? this.screen.getScreenHeight() : contentBottom;

		this.videoSeekSlider.method_46421(layout.sliderWidgetX());
		this.videoSeekSlider.method_46419(layout.sliderWidgetY());
		this.videoSeekSlider.method_25358(layout.sliderWidgetWidth());
		this.videoSeekSlider.method_53533(PseudoVideoLayout.SLIDER_INNER_HEIGHT);
		this.videoSeekSlider.field_22763 = PseudoVideoService.get().getPrepareState() == PseudoVideoService.PrepareState.READY;
		this.videoSeekSlider.syncFromPlayback();
		boolean sliderVisible = layout.sliderBlockTop() + layout.sliderBlockHeight() >= clipTop
				&& layout.sliderBlockTop() <= clipBottom;
		this.videoSeekSlider.field_22764 = sliderVisible;

		int controlsY = layout.controlsWidgetY();

		this.videoSeekBackButton.method_46421(layout.seekBackButtonX());
		this.videoSeekBackButton.method_46419(controlsY);
		this.videoPlayPauseButton.method_46421(layout.playButtonX());
		this.videoPlayPauseButton.method_46419(controlsY);
		this.videoPlayPauseButton.method_25355(this.getVideoPlayPauseLabel());
		this.videoSeekForwardButton.method_46421(layout.seekForwardButtonX());
		this.videoSeekForwardButton.method_46419(controlsY);
		this.videoFullscreenButton.method_46421(layout.fullscreenButtonX());
		this.videoFullscreenButton.method_46419(controlsY);
		this.videoFullscreenButton.method_25355(this.getVideoFullscreenLabel());

		boolean controlsVisible = layout.controlsBlockTop() + layout.controlsBlockHeight() >= clipTop
				&& layout.controlsBlockTop() <= clipBottom;
		this.videoSeekBackButton.field_22764 = controlsVisible;
		this.videoPlayPauseButton.field_22764 = controlsVisible;
		this.videoSeekForwardButton.field_22764 = controlsVisible;
		this.videoFullscreenButton.field_22764 = controlsVisible;
	}

	private void setVideoControlsVisible(boolean visible) {
		if (this.videoSeekBackButton != null) {
			this.videoSeekBackButton.field_22764 = visible;
		}
		if (this.videoPlayPauseButton != null) {
			this.videoPlayPauseButton.field_22764 = visible;
		}
		if (this.videoSeekForwardButton != null) {
			this.videoSeekForwardButton.field_22764 = visible;
		}
		if (this.videoFullscreenButton != null) {
			this.videoFullscreenButton.field_22764 = visible;
		}
		if (this.videoSeekSlider != null) {
			this.videoSeekSlider.field_22764 = visible;
		}
	}

	private void applyScrollToControls() {
		int listTop = this.getListTop();
		int contentBottom = this.getScrollableContentBottom();
		int toggleIndex = 0;
		int studyIndex = 0;

		for (LayoutRow row : this.layoutRows) {
			if (row.isEmpty || row.isStudyBody || row.isDisclaimer || row.isSectionsHeader || row.isSectionBlock) {
				continue;
			}
			int displayY = row.y - this.scrollOffset;
			boolean visible = displayY >= listTop - 1 && displayY + row.rowHeight <= contentBottom + 1;

			if (row.sectionTitle != null) {
				if (toggleIndex < this.sectionToggleButtons.size()) {
					class_4185 arrow = this.sectionToggleButtons.get(toggleIndex++);
					arrow.method_46419(displayY);
					arrow.method_53533(ROW_HEIGHT);
					arrow.field_22764 = visible;
				}
			} else if (row.lessonTitle != null && studyIndex < this.studyButtons.size()) {
				class_4185 study = this.studyButtons.get(studyIndex++);
				study.method_46419(displayY);
				study.field_22764 = visible;
			}
		}
	}

	private int getMaxScroll() {
		if (this.isStudying()) {
			StudyContent content = this.resolveStudyContent();
			if (content == null) {
				return 0;
			}
			int innerWidth = this.screen.getContentWidth() - RedstoneMasterScreen.CONTENT_INNER_PADDING * 2 - 4;
			return Math.max(0, this.measureStudyHeight(content, innerWidth) - this.getListViewHeight());
		}
		return Math.max(0, this.getListContentHeight() - this.getListViewHeight());
	}

	private int measureStudyHeight(StudyContent content, int innerWidth) {
		int height = 0;
		height += this.screen.method_64506().method_1728(class_2561.method_43470(content.title()), innerWidth).size()
				* this.screen.method_64506().field_2000 + 4;
		boolean hasVideo = !content.videos().isEmpty();
		StudyBodyParts bodyParts = hasVideo ? this.splitStudyBodyForVideo(content.body()) : new StudyBodyParts("", content.body());
		String bodyAfterVideo = hasVideo ? bodyParts.remainingBody() : content.body();
		if (hasVideo) {
			if (this.hasStudyGoalBeforeVideo(content.body(), bodyParts)) {
				height += this.measureStudyGoalBeforeVideoHeight(bodyParts.goalParagraph(), innerWidth);
			} else {
				height += VIDEO_GAP;
			}
			height += PseudoVideoLayout.embedded(
					0,
					0,
					innerWidth,
					VIDEO_CONTROLS_HEIGHT,
					this.getVideoControlsInnerWidth(),
					this.getVideoTimeBlockWidth(),
					VIDEO_FULLSCREEN_BUTTON_WIDTH,
					this.getVideoSeekBackWidth(),
					VIDEO_PLAY_BUTTON_WIDTH,
					this.getVideoSeekForwardWidth(),
					this.screen.method_64506()
			).totalHeight();
			height += VIDEO_AFTER_CONTROLS_GAP;
		}
		if (!bodyAfterVideo.isBlank()) {
			height += this.screen.method_64506().method_1728(class_2561.method_43470(bodyAfterVideo), innerWidth).size()
					* this.screen.method_64506().field_2000;
		}
		height += IMAGE_GAP;
		height += TutorialTextures.measureImagesHeight(content.images(), innerWidth, IMAGE_GAP);
		height += 4;
		if (content.sources() != null && !content.sources().isBlank()) {
			height += this.screen.method_64506().method_1728(class_2561.method_43470(content.sources()), innerWidth).size()
					* this.screen.method_64506().field_2000;
		}
		return height + 16;
	}

	private int getListContentHeight() {
		if (this.layoutRows.isEmpty()) {
			return 0;
		}
		LayoutRow last = this.layoutRows.get(this.layoutRows.size() - 1);
		if (last.isStudyBody) {
			StudyContent content = this.resolveStudyContent();
			if (content == null) {
				return 0;
			}
			int innerWidth = this.screen.getContentWidth() - RedstoneMasterScreen.CONTENT_INNER_PADDING * 2 - 4;
			return this.measureStudyHeight(content, innerWidth);
		}
		return last.y + last.rowHeight - this.getListTop();
	}

	int getSearchY() {
		return this.screen.getContentY() + RedstoneMasterScreen.CONTENT_INNER_PADDING;
	}

	int getSearchHeight() {
		return Math.max(SEARCH_HEIGHT, this.screen.method_64506().field_2000 + 10);
	}

	int getListTop() {
		return this.getSearchY() + this.getSearchHeight() + this.getGapAfterSearch();
	}

	private int getGapAfterSearch() {
		return this.screen.method_64506().field_2000 * SEARCH_LINE_GAP;
	}

	private int getSectionsHeaderTopGap() {
		return this.screen.method_64506().field_2000 * SECTIONS_HEADER_EXTRA_GAP_LINES;
	}

	private int getContentBottom() {
		return this.screen.getContentY() + this.screen.getContentHeight() - RedstoneMasterScreen.CONTENT_INNER_PADDING;
	}

	private int getCollapseAllButtonY() {
		return this.getContentBottom() - ROW_HEIGHT;
	}

	private int getScrollableContentBottom() {
		if (this.isStudying()) {
			return this.getContentBottom();
		}
		return this.getCollapseAllButtonY() - COLLAPSE_ALL_GAP;
	}

	private int getListViewHeight() {
		return this.getScrollableContentBottom() - this.getListTop();
	}

	private void clampScrollOffset() {
		this.scrollOffset = (int) Math.clamp(this.scrollOffset, 0, this.getMaxScroll());
		this.updateLessonCompletionFromScroll();
	}

	private record StudyContent(String title, String body, String sources, List<String> images, List<String> videos) {
	}

	private record StudyBodyParts(String goalParagraph, String remainingBody) {
	}

	private static final class LayoutRow {
		private final String sectionId;
		private final String lessonId;
		private final String sectionTitle;
		private final String sectionSummary;
		private final String lessonTitle;
		private final int y;
		private final int rowHeight;
		private final boolean isEmpty;
		private final boolean isStudyBody;
		private final boolean isDisclaimer;
		private final boolean isSectionsHeader;
		private final boolean isSectionBlock;

		private LayoutRow(
				String sectionId,
				String lessonId,
				String sectionTitle,
				String sectionSummary,
				String lessonTitle,
				int y,
				int rowHeight,
				boolean isEmpty,
				boolean isStudyBody,
				boolean isDisclaimer,
				boolean isSectionsHeader,
				boolean isSectionBlock
		) {
			this.sectionId = sectionId;
			this.lessonId = lessonId;
			this.sectionTitle = sectionTitle;
			this.sectionSummary = sectionSummary;
			this.lessonTitle = lessonTitle;
			this.y = y;
			this.rowHeight = rowHeight;
			this.isEmpty = isEmpty;
			this.isStudyBody = isStudyBody;
			this.isDisclaimer = isDisclaimer;
			this.isSectionsHeader = isSectionsHeader;
			this.isSectionBlock = isSectionBlock;
		}

		static LayoutRow sectionHeader(String sectionId, String sectionTitle, int y, int rowHeight) {
			return new LayoutRow(sectionId, null, sectionTitle, null, null, y, rowHeight, false, false, false, false, false);
		}

		static LayoutRow sectionSummary(String sectionSummary, int y, int rowHeight) {
			return new LayoutRow(null, null, null, sectionSummary, null, y, rowHeight, false, false, false, false, false);
		}

		static LayoutRow lesson(String sectionId, String lessonId, String lessonTitle, int y, int rowHeight) {
			return new LayoutRow(sectionId, lessonId, null, null, lessonTitle, y, rowHeight, false, false, false, false, false);
		}

		static LayoutRow sectionBlock(int y, int rowHeight) {
			return new LayoutRow(null, null, null, null, null, y, rowHeight, false, false, false, false, true);
		}

		static LayoutRow disclaimer(int y, int rowHeight) {
			return new LayoutRow(null, null, null, null, null, y, rowHeight, false, false, true, false, false);
		}

		static LayoutRow sectionsHeader(int y, int rowHeight) {
			return new LayoutRow(null, null, null, null, null, y, rowHeight, false, false, false, true, false);
		}

		static LayoutRow empty(int y) {
			return new LayoutRow(null, null, null, null, null, y, ROW_HEIGHT, true, false, false, false, false);
		}

		static LayoutRow studyBody(int y) {
			return new LayoutRow(null, null, null, null, null, y, 0, false, true, false, false, false);
		}
	}
}
