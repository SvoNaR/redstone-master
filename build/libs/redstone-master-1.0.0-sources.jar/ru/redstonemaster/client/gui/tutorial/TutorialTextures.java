package ru.redstonemaster.client.gui.tutorial;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_332;

public final class TutorialTextures {
	private static final int IMAGE_COLOR = 0xFFFFFFFF;
	private static final int MAX_DISPLAY_SIZE = 200;
	private static final Map<class_2960, int[]> SIZE_CACHE = new HashMap<>();

	private TutorialTextures() {
	}

	public static class_2960 textureId(String path) {
		if (path == null || path.isBlank()) {
			return null;
		}
		String normalized = path.replace('\\', '/');
		if (!normalized.startsWith("textures/")) {
			normalized = "textures/" + normalized;
		}
		return class_2960.method_60655("redstone-master", normalized);
	}

	private static int[] resolveTextureSize(class_2960 id) {
		return SIZE_CACHE.computeIfAbsent(id, key -> {
			class_310 client = class_310.method_1551();
			if (client == null) {
				return new int[] {64, 64};
			}
			try {
				class_3298 resource = client.method_1478().getResourceOrThrow(key);
				try (class_1011 image = class_1011.method_4309(resource.method_14482())) {
					return new int[] {image.method_4307(), image.method_4323()};
				}
			} catch (Exception e) {
				return new int[] {64, 64};
			}
		});
	}

	private static int[] computeDisplaySize(int texWidth, int texHeight, int maxWidth) {
		int limit = Math.min(maxWidth, MAX_DISPLAY_SIZE);
		if (texWidth <= limit && texHeight <= limit) {
			return new int[] {texWidth, texHeight};
		}
		float scale = Math.min((float) limit / texWidth, (float) limit / texHeight);
		return new int[] {
				Math.max(1, Math.round(texWidth * scale)),
				Math.max(1, Math.round(texHeight * scale))
		};
	}

	public static int measureImagesHeight(List<String> imagePaths, int maxWidth, int gap) {
		int total = 0;
		for (String path : imagePaths) {
			if (path == null || path.isBlank()) {
				continue;
			}
			class_2960 id = textureId(path);
			if (id == null) {
				continue;
			}
			int[] texSize = resolveTextureSize(id);
			int[] display = computeDisplaySize(texSize[0], texSize[1], maxWidth);
			total += display[1] + gap;
		}
		return total;
	}

	public static int renderImages(
			class_332 graphics,
			net.minecraft.class_327 font,
			List<String> imagePaths,
			int x,
			int y,
			int maxWidth,
			int listTop,
			int contentBottom,
			int gap
	) {
		class_310 client = class_310.method_1551();
		for (String path : imagePaths) {
			class_2960 id = textureId(path);
			if (id == null) {
				continue;
			}
			client.method_1531().method_4619(id);
			int[] texSize = resolveTextureSize(id);
			int texW = texSize[0];
			int texH = texSize[1];
			int[] display = computeDisplaySize(texW, texH, maxWidth);
			int displayW = display[0];
			int displayH = display[1];

			if (y + displayH >= listTop && y <= contentBottom) {
				graphics.method_25293(
						class_10799.field_56883,
						id,
						x,
						y,
						0.0f,
						0.0f,
						displayW,
						displayH,
						texW,
						texH,
						texW,
						texH,
						IMAGE_COLOR
				);
			}
			y += displayH + gap;
		}
		return y;
	}

	public static void clearCache() {
		SIZE_CACHE.clear();
	}
}
