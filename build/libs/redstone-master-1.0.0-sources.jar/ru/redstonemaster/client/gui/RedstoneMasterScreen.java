package ru.redstonemaster.client.gui;

import ru.redstonemaster.RedstoneMasterClient;
import ru.redstonemaster.client.auth.ModWebAuthService;
import ru.redstonemaster.client.profile.ModAvatarManager;
import ru.redstonemaster.client.gui.tutorial.TutorialSessionPersistence;
import ru.redstonemaster.client.gui.tutorial.TutorialStudyTarget;
import ru.redstonemaster.config.ModConfig;
import ru.redstonemaster.config.ModContentLanguage;
import ru.redstonemaster.config.ModSessionState;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_5481;
import net.minecraft.class_7919;

public class RedstoneMasterScreen extends class_437 {
	public static final int CONTENT_INNER_PADDING = 6;
	private static final int PANEL_PADDING = 8;
	private static final int NAV_BAR_HEIGHT = 20;
	private static final int ICON_BUTTON_SIZE = 20;
	private static final int CLOSE_BUTTON_GAP = 2;
	private static final int TITLE_TOP_PADDING = 4;
	private static final int TITLE_TO_NAV_GAP = 2;
	private static final int NAV_DOWN_OFFSET = 4;
	private static final int CONTENT_TOP_GAP = 10;
	private static final int TEXT_COLOR = 0xFFFFFFFF;
	private static final int IMAGE_COLOR = 0xFFFFFFFF;
	private static final int LINE_COLOR_NORMAL = 0xFF000000;
	private static final int LINE_COLOR_HIGH_CONTRAST = 0xFFFFFFFF;
	private static final int TITLE_COLOR = 0xFF800020;
	private static final float TITLE_SCALE = 1.5f;
	private static final class_2960 MAIN_MENU_PHOTO = class_2960.method_60655(
			"redstone-master", "textures/gui/photo1_main_menu.png");
	private static final class_2960 PROFILE_AVATAR = class_2960.method_60655(
			"redstone-master", "textures/gui/profile_avatar.png");
	private static final int PROFILE_AVATAR_TEXTURE_SIZE = 8;
	private static final int PROFILE_AVATAR_DISPLAY_SIZE = 8;
	private static final int PROFILE_AVATAR_GAP = 2;
	private static final int MAIN_MENU_PHOTO_TEXTURE_SIZE = 1024;
	private static final int MAIN_MENU_PHOTO_DISPLAY_SIZE = 40;
	private static final int MAIN_MENU_PHOTO_FRAME_PADDING = 2;
	private static final int MAIN_MENU_CREDIT_GROUP_PADDING = 4;
	private static final int MAIN_MENU_CREDIT_GAP = 4;
	private static final float MAIN_MENU_GREETING_SCALE = 1.5f;
	private static final int MAIN_MENU_GREETING_BOTTOM_GAP_LINES = 1;
	private static final int MAIN_MENU_BLOCK_GAP = 4;
	private static final int MAIN_MENU_SECTION_GAP = 7;
	private static final int MAIN_MENU_LINE_EXTRA = 3;
	private static final int MAIN_MENU_SECTION_COLOR = 0xFFE8C070;
	private static final int CREDIT_SVONAR_COLOR = 0xFF800020;
	private static final int CREDIT_FOXICY_COLOR = 0xFF55FF55;
	private static final String MAIN_MENU_BRAND = "Redstone Master";
	private static final String MAIN_MENU_GREETING_KEY = "gui.redstone-master.main_menu.greeting";
	private static final String MAIN_MENU_TITLE_SUFFIX_KEY = "gui.redstone-master.main_menu.title_suffix";
	private static final String MAIN_MENU_CREDIT_PREFIX_KEY = "gui.redstone-master.main_menu.credit_prefix";

	private RedstoneMasterTab currentTab = RedstoneMasterTab.MAIN_MENU;
	private final RedstoneMasterSettingsPanel settingsPanel = new RedstoneMasterSettingsPanel(this);
	private final RedstoneMasterTutorialPanel tutorialPanel = new RedstoneMasterTutorialPanel(this);
	private final RedstoneMasterProfilePanel profilePanel = new RedstoneMasterProfilePanel(this);
	@Nullable
	private final class_437 previousScreen;
	private boolean sessionRestored;
	private boolean navigationHistoryInitialized;
	private boolean applyingNavigationHistory;
	private boolean openProfileOnInit;
	private boolean showLoginSuccessOnInit;
	private final RedstoneMasterNavigationHistory navigationHistory = new RedstoneMasterNavigationHistory();

	private int panelX;
	private int panelY;
	private int panelWidth;
	private int panelHeight;
	private int titleY;
	private int navY;
	private int separatorY;
	private int contentX;
	private int contentY;
	private int contentWidth;
	private int contentHeight;
	@Nullable
	private class_4185 profileTabButton;

	public RedstoneMasterScreen(@Nullable class_437 previousScreen) {
		this(previousScreen, false, false);
	}

	public RedstoneMasterScreen(@Nullable class_437 previousScreen, boolean openProfileTab, boolean showLoginSuccess) {
		super(ModContentLanguage.translatable("gui.redstone-master.title"));
		this.previousScreen = previousScreen;
		this.openProfileOnInit = openProfileTab;
		this.showLoginSuccessOnInit = showLoginSuccess;
	}

	@Override
	protected void method_25426() {
		if (ModConfig.get().initializeLanguageOnFirstOpen()) {
			ModContentLanguage.clearCache();
		}
		if (!this.sessionRestored) {
			this.restoreSessionState();
			this.sessionRestored = true;
		}
		if (ModWebAuthService.get().consumeOpenProfileTab()) {
			this.openProfileOnInit = true;
			this.showLoginSuccessOnInit = ModWebAuthService.get().consumeLoginSuccess();
		}
		if (this.openProfileOnInit) {
			this.currentTab = RedstoneMasterTab.PROFILE;
			this.openProfileOnInit = false;
		}
		if (this.showLoginSuccessOnInit) {
			this.profilePanel.setShowLoginSuccess(true);
			this.showLoginSuccessOnInit = false;
		}
		if (this.currentTab == RedstoneMasterTab.PROFILE) {
			this.profilePanel.onTabOpened();
		}
		this.rebuildAllWidgets();
		if (!this.navigationHistoryInitialized) {
			this.navigationHistory.reset(this.captureNavigationSnapshot());
			this.navigationHistoryInitialized = true;
		}
	}

	@Override
	public void method_25419() {
		this.persistSessionState();
		if (this.field_22787 != null) {
			this.field_22787.method_1507(this.previousScreen);
		}
	}

	private void restoreSessionState() {
		if (!ModConfig.get().rememberSession || !ModSessionState.get().hasSaved()) {
			this.applyDefaultSessionUi();
			return;
		}
		ModSessionState session = ModSessionState.get();
		RedstoneMasterTab savedTab = RedstoneMasterTab.fromName(session.getLastTab());
		this.currentTab = savedTab != null ? savedTab : RedstoneMasterTab.MAIN_MENU;
		this.settingsPanel.setScrollOffset(session.getSettingsScrollOffset());
		this.tutorialPanel.restoreExpandedSections(session.getExpandedTutorialSections());
		TutorialStudyTarget studyTarget = TutorialSessionPersistence.fromStorageKey(session.getTutorialStudyTarget());
		if (studyTarget != null && !this.tutorialPanel.isValidStudyTarget(studyTarget)) {
			studyTarget = null;
		}
		if (studyTarget != null) {
			this.tutorialPanel.restoreNavigationState(
					studyTarget,
					session.getTutorialStudyScrollOffset(),
					session.getTutorialScrollOffset()
			);
		} else {
			this.tutorialPanel.restoreNavigationState(null, session.getTutorialScrollOffset(), 0);
		}
	}

	private void persistSessionState() {
		if (!ModConfig.get().rememberSession) {
			ModSessionState.get().clear();
			return;
		}
		TutorialStudyTarget studyTarget = this.tutorialPanel.getStudyTargetForNavigation();
		ModSessionState.get().save(
				this.currentTab.name(),
				this.settingsPanel.getScrollOffset(),
				this.tutorialPanel.getListScrollOffsetForPersistence(),
				this.tutorialPanel.getExpandedSectionsCsv(),
				TutorialSessionPersistence.toStorageKey(studyTarget),
				studyTarget != null ? this.tutorialPanel.getScrollOffset() : 0
		);
	}

	/** Сброс прокрутки и обучения в памяти (вкладка не меняется). */
	void clearStoredSessionContent() {
		this.settingsPanel.setScrollOffset(0);
		this.tutorialPanel.restoreExpandedSections("");
		this.tutorialPanel.restoreNavigationState(null, 0, 0);
		this.navigationHistory.reset(this.captureNavigationSnapshot());
	}

	/** При открытии мода без сохранения сессии — главная вкладка и сброс позиций. */
	void applyDefaultSessionUi() {
		this.currentTab = RedstoneMasterTab.MAIN_MENU;
		this.clearStoredSessionContent();
	}

	public void rebuildAllWidgets() {
		this.updatePanelBounds();
		this.rebuildNavigation();
	}

	void rebuildSettingsWidgets() {
		this.rebuildNavigation();
	}

	void rebuildTutorialWidgets() {
		this.rebuildNavigation();
	}

	private void updatePanelBounds() {
		double panelScale = ModConfig.get().panelScale;
		this.panelWidth = (int) (this.field_22789 * panelScale);
		this.panelHeight = (int) (this.field_22790 * panelScale);
		this.panelX = (this.field_22789 - this.panelWidth) / 2;
		this.panelY = (this.field_22790 - this.panelHeight) / 2;

		int innerX = this.panelX + PANEL_PADDING;
		int innerWidth = this.panelWidth - PANEL_PADDING * 2;

		this.titleY = this.panelY + PANEL_PADDING + TITLE_TOP_PADDING;
		int titleHeight = this.getScaledTitleHeight();
		this.separatorY = this.titleY + titleHeight + 2;
		this.navY = this.titleY + titleHeight + TITLE_TO_NAV_GAP + NAV_DOWN_OFFSET;
		this.contentX = innerX;
		this.contentY = this.navY + NAV_BAR_HEIGHT + CONTENT_TOP_GAP;
		this.contentWidth = innerWidth;
		this.contentHeight = this.panelY + this.panelHeight - PANEL_PADDING - this.contentY;
	}

	private void rebuildNavigation() {
		this.method_37067();
		this.settingsPanel.dispose();
		this.tutorialPanel.dispose();
		this.profilePanel.dispose();

		int innerX = this.panelX + PANEL_PADDING;
		int innerWidth = this.panelWidth - PANEL_PADDING * 2;

		int closeAreaWidth = ICON_BUTTON_SIZE + CLOSE_BUTTON_GAP;
		int navButtonWidth = (innerWidth - closeAreaWidth) / 4;

		this.method_37063(class_4185.method_46430(
						ModContentLanguage.translatable("gui.redstone-master.tab.main_menu"),
						button -> this.selectTab(RedstoneMasterTab.MAIN_MENU))
				.method_46434(innerX, this.navY, navButtonWidth, NAV_BAR_HEIGHT)
				.method_46431());

		this.method_37063(class_4185.method_46430(
						ModContentLanguage.translatable("gui.redstone-master.tab.tutorial"),
						button -> this.selectTab(RedstoneMasterTab.TUTORIAL))
				.method_46434(innerX + navButtonWidth, this.navY, navButtonWidth, NAV_BAR_HEIGHT)
				.method_46431());

		this.method_37063(class_4185.method_46430(
						ModContentLanguage.translatable("gui.redstone-master.tab.settings"),
						button -> this.selectTab(RedstoneMasterTab.SETTINGS))
				.method_46434(innerX + navButtonWidth * 2, this.navY, navButtonWidth, NAV_BAR_HEIGHT)
				.method_46431());

		this.profileTabButton = class_4185.method_46430(
						ModContentLanguage.translatable("gui.redstone-master.tab.profile"),
						button -> this.selectTab(RedstoneMasterTab.PROFILE))
				.method_46434(innerX + navButtonWidth * 3, this.navY, navButtonWidth, NAV_BAR_HEIGHT)
				.method_46431();
		this.method_37063(this.profileTabButton);

		int closeX = innerX + navButtonWidth * 4 + CLOSE_BUTTON_GAP;
		this.method_37063(class_4185.method_46430(
						class_2561.method_43470("X"),
						button -> this.method_25419())
				.method_46434(closeX, this.navY, ICON_BUTTON_SIZE, ICON_BUTTON_SIZE)
				.method_46436(class_7919.method_47407(ModContentLanguage.translatable("gui.redstone-master.close")))
				.method_46431());

		if (this.currentTab == RedstoneMasterTab.SETTINGS) {
			this.settingsPanel.rebuildWidgets();
		}
		if (this.currentTab == RedstoneMasterTab.TUTORIAL) {
			this.tutorialPanel.rebuildWidgets();
		}
		if (this.currentTab == RedstoneMasterTab.PROFILE) {
			this.profilePanel.rebuildWidgets();
		}
	}

	public void openProfileAfterAuth(boolean showLoginSuccess) {
		this.currentTab = RedstoneMasterTab.PROFILE;
		this.profilePanel.setShowLoginSuccess(showLoginSuccess);
		this.profilePanel.onTabOpened();
		this.rebuildNavigation();
	}

	private void selectTab(RedstoneMasterTab tab) {
		if (tab == RedstoneMasterTab.TUTORIAL && this.currentTab == RedstoneMasterTab.TUTORIAL) {
			this.tutorialPanel.resetToHome();
			this.rebuildNavigation();
			return;
		}
		if (this.currentTab == RedstoneMasterTab.SETTINGS && tab != RedstoneMasterTab.SETTINGS) {
			this.persistSettingsScroll();
		}
		if (this.currentTab == RedstoneMasterTab.TUTORIAL && tab != RedstoneMasterTab.TUTORIAL) {
			this.persistTutorialScroll();
		}
		this.currentTab = tab;
		if (this.currentTab == RedstoneMasterTab.PROFILE) {
			this.profilePanel.onTabOpened();
		}
		this.rebuildNavigation();
		this.onNavigationPointReached();
	}

	void onNavigationPointReached() {
		if (!this.applyingNavigationHistory) {
			this.navigationHistory.push(this.captureNavigationSnapshot());
		}
	}

	public void navigateBack() {
		RedstoneMasterNavigationSnapshot snapshot = this.navigationHistory.goBack();
		if (snapshot != null) {
			this.applyNavigationSnapshot(snapshot);
			return;
		}
		this.method_25419();
	}

	public void navigateForward() {
		RedstoneMasterNavigationSnapshot snapshot = this.navigationHistory.goForward();
		if (snapshot != null) {
			this.applyNavigationSnapshot(snapshot);
		}
	}

	private RedstoneMasterNavigationSnapshot captureNavigationSnapshot() {
		return new RedstoneMasterNavigationSnapshot(
				this.currentTab,
				this.tutorialPanel.getStudyTargetForNavigation(),
				this.tutorialPanel.getScrollOffset(),
				this.tutorialPanel.getSavedListScrollOffset(),
				this.settingsPanel.getScrollOffset(),
				this.tutorialPanel.getExpandedSectionsCsv()
		);
	}

	private void applyNavigationSnapshot(RedstoneMasterNavigationSnapshot snapshot) {
		this.applyingNavigationHistory = true;
		try {
			if (this.currentTab == RedstoneMasterTab.SETTINGS && snapshot.tab() != RedstoneMasterTab.SETTINGS) {
				this.persistSettingsScroll();
			}
			if (this.currentTab == RedstoneMasterTab.TUTORIAL && snapshot.tab() != RedstoneMasterTab.TUTORIAL) {
				this.persistTutorialScroll();
			}

			this.currentTab = snapshot.tab();
			this.settingsPanel.setScrollOffset(snapshot.settingsScrollOffset());
			this.tutorialPanel.restoreExpandedSections(snapshot.expandedTutorialSections());
			this.tutorialPanel.restoreNavigationState(
					snapshot.studyTarget(),
					snapshot.tutorialScrollOffset(),
					snapshot.tutorialSavedListScrollOffset()
			);
			this.rebuildNavigation();
		} finally {
			this.applyingNavigationHistory = false;
		}
	}

	private void persistTutorialScroll() {
		this.persistSessionState();
	}

	private void persistSettingsScroll() {
		this.persistSessionState();
	}

	@Override
	public void method_25410(int width, int height) {
		super.method_25410(width, height);
		this.rebuildAllWidgets();
	}

	@Override
	public boolean method_25402(class_11909 event, boolean doubled) {
		if (RedstoneMasterClient.navigateBackKey.method_1433(event)) {
			this.navigateBack();
			return true;
		}
		if (RedstoneMasterClient.navigateForwardKey.method_1433(event)) {
			this.navigateForward();
			return true;
		}
		return super.method_25402(event, doubled);
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
		if (this.currentTab == RedstoneMasterTab.SETTINGS && this.settingsPanel.mouseScrolled(scrollX, scrollY)) {
			return true;
		}
		if (this.currentTab == RedstoneMasterTab.TUTORIAL && this.tutorialPanel.mouseScrolled(scrollX, scrollY)) {
			return true;
		}
		return super.method_25401(mouseX, mouseY, scrollX, scrollY);
	}

	@Override
	public void method_25420(class_332 graphics, int mouseX, int mouseY, float delta) {
		if (this.shouldShowTitleMenuPanorama()) {
			this.method_57728(graphics, delta);
		}
		this.method_57736(graphics, this.panelX, this.panelY, this.panelWidth, this.panelHeight);
	}

	private boolean shouldShowTitleMenuPanorama() {
		return this.previousScreen instanceof class_442;
	}

	private void renderProfileTabAvatar(class_332 graphics) {
		if (this.profileTabButton == null || !this.profileTabButton.field_22764) {
			return;
		}
		String label = ModContentLanguage.get("gui.redstone-master.tab.profile");
		int labelWidth = this.field_22793.method_1727(label);
		int avatarX = this.profileTabButton.method_46426() + (this.profileTabButton.method_25368() + labelWidth) / 2 + PROFILE_AVATAR_GAP;
		int avatarY = this.profileTabButton.method_46427() + (this.profileTabButton.method_25364() - PROFILE_AVATAR_DISPLAY_SIZE) / 2;
		class_2960 avatarId = ModAvatarManager.getTabAvatarId();
		int textureWidth = ModAvatarManager.getTabAvatarTextureWidth();
		int textureHeight = ModAvatarManager.getTabAvatarTextureHeight();
		graphics.method_25293(
				class_10799.field_56883,
				avatarId,
				avatarX,
				avatarY,
				0.0f,
				0.0f,
				PROFILE_AVATAR_DISPLAY_SIZE,
				PROFILE_AVATAR_DISPLAY_SIZE,
				textureWidth,
				textureHeight,
				textureWidth,
				textureHeight,
				IMAGE_COLOR
		);
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
		if (this.currentTab == RedstoneMasterTab.TUTORIAL) {
			this.tutorialPanel.layoutStudyVideoControls();
		}
		super.method_25394(graphics, mouseX, mouseY, delta);
		this.renderProfileTabAvatar(graphics);
		this.renderDecorations(graphics);
		this.renderContent(graphics);
		if (this.currentTab == RedstoneMasterTab.SETTINGS) {
			this.settingsPanel.renderLabels(graphics);
		}
		if (this.currentTab == RedstoneMasterTab.TUTORIAL) {
			this.tutorialPanel.render(graphics);
		}
		if (this.currentTab == RedstoneMasterTab.PROFILE) {
			this.profilePanel.render(graphics);
		}
	}

	private int getLineColor() {
		return ModConfig.get().highContrastBorders ? LINE_COLOR_HIGH_CONTRAST : LINE_COLOR_NORMAL;
	}

	private int getScaledTitleHeight() {
		return (int) Math.ceil(this.field_22793.field_2000 * TITLE_SCALE);
	}

	private class_2561 getTitleComponent() {
		return class_2561.method_43470(ModContentLanguage.get("gui.redstone-master.title"))
				.method_27696(class_2583.field_24360.method_10982(true));
	}

	private void renderTitle(class_332 graphics) {
		int centerX = this.panelX + this.panelWidth / 2;
		float anchorY = this.titleY + this.field_22793.field_2000 / 2.0f;

		var pose = graphics.method_51448();
		pose.pushMatrix();
		pose.translate(centerX, anchorY);
		pose.scale(TITLE_SCALE, TITLE_SCALE);
		graphics.method_27534(
				this.field_22793,
				this.getTitleComponent(),
				0,
				(int) (-this.field_22793.field_2000 / 2.0f),
				TITLE_COLOR
		);
		pose.popMatrix();
	}

	private void renderDecorations(class_332 graphics) {
		int lineColor = this.getLineColor();
		graphics.method_73198(this.panelX, this.panelY, this.panelWidth, this.panelHeight, lineColor);
		this.renderTitle(graphics);

		graphics.method_51738(
				this.panelX + PANEL_PADDING,
				this.panelX + this.panelWidth - PANEL_PADDING,
				this.separatorY,
				lineColor
		);

		graphics.method_73198(this.contentX, this.contentY, this.contentWidth, this.contentHeight, lineColor);
	}

	private void renderContent(class_332 graphics) {
		switch (this.currentTab) {
			case MAIN_MENU -> this.renderMainMenuContent(graphics);
			case SETTINGS -> { /* подписи рисуются в settingsPanel.renderLabels */ }
			case TUTORIAL -> { /* tutorialPanel.render */ }
			case PROFILE -> { /* profilePanel.render */ }
		}
	}

	private void renderMainMenuContent(class_332 graphics) {
		int textX = this.contentX + CONTENT_INNER_PADDING;
		int textY = this.contentY + CONTENT_INNER_PADDING;
		int textWidth = this.contentWidth - CONTENT_INNER_PADDING * 2;
		int maxTextBottom = this.contentY + this.contentHeight - CONTENT_INNER_PADDING - this.getMainMenuFooterReservedHeight();

		textY = this.renderScaledTextBlock(
				graphics,
				ModContentLanguage.translatable(MAIN_MENU_GREETING_KEY),
				textX,
				textY,
				textWidth,
				MAIN_MENU_GREETING_SCALE,
				maxTextBottom
		);
		textY += this.field_22793.field_2000 * MAIN_MENU_GREETING_BOTTOM_GAP_LINES;
		textY = this.renderStyledTextBlock(
				graphics,
				this.buildMainMenuTitleLine(),
				textX,
				textY,
				textWidth,
				maxTextBottom
		);
		textY += MAIN_MENU_BLOCK_GAP;
		this.renderMainMenuBody(
				graphics,
				textX,
				textY,
				textWidth,
				maxTextBottom
		);
		this.renderMainMenuFooter(graphics);
	}

	private void renderMainMenuBody(
			class_332 graphics,
			int textX,
			int textY,
			int textWidth,
			int maxTextBottom
	) {
		String body = ModContentLanguage.get("gui.redstone-master.main_menu.body");
		for (String block : body.split("\n\n")) {
			if (block.isBlank()) {
				continue;
			}
			int newline = block.indexOf('\n');
			String header = newline >= 0 ? block.substring(0, newline).trim() : block.trim();
			String content = newline >= 0 ? block.substring(newline + 1).trim() : "";

			for (class_5481 line : this.field_22793.method_1728(
					class_2561.method_43470(header).method_27692(net.minecraft.class_124.field_1067),
					textWidth
			)) {
				if (textY + this.field_22793.field_2000 > maxTextBottom) {
					return;
				}
				graphics.method_51430(this.field_22793, line, textX, textY, MAIN_MENU_SECTION_COLOR, true);
				textY += this.field_22793.field_2000 + MAIN_MENU_LINE_EXTRA;
			}

			if (!content.isEmpty()) {
				for (class_5481 line : this.field_22793.method_1728(class_2561.method_43470(content), textWidth)) {
					if (textY + this.field_22793.field_2000 > maxTextBottom) {
						return;
					}
					graphics.method_51430(this.field_22793, line, textX, textY, TEXT_COLOR, true);
					textY += this.field_22793.field_2000 + MAIN_MENU_LINE_EXTRA;
				}
			}

			textY += MAIN_MENU_SECTION_GAP;
		}
	}

	private class_2561 buildMainMenuTitleLine() {
		return this.coloredLiteral(MAIN_MENU_BRAND, TEXT_COLOR)
				.method_10852(this.coloredLiteral(ModContentLanguage.get(MAIN_MENU_TITLE_SUFFIX_KEY), TEXT_COLOR));
	}

	private class_2561 buildMainMenuCredit() {
		return this.coloredLiteral(ModContentLanguage.get(MAIN_MENU_CREDIT_PREFIX_KEY), TEXT_COLOR)
				.method_10852(this.coloredLiteral("SvoNaR", CREDIT_SVONAR_COLOR))
				.method_10852(this.coloredLiteral(" & ", TEXT_COLOR))
				.method_10852(this.coloredLiteral("foxicy", CREDIT_FOXICY_COLOR))
				.method_10852(this.coloredLiteral(" <3", TEXT_COLOR));
	}

	private class_5250 coloredLiteral(String text, int color) {
		return class_2561.method_43470(text)
				.method_27694(style -> style.method_27703(class_5251.method_27717(color & 0xFFFFFF)));
	}

	private int getMainMenuFooterReservedHeight() {
		int photoFrameSize = MAIN_MENU_PHOTO_DISPLAY_SIZE + MAIN_MENU_PHOTO_FRAME_PADDING * 2;
		int contentHeight = Math.max(this.field_22793.field_2000, photoFrameSize);
		return contentHeight + MAIN_MENU_CREDIT_GROUP_PADDING * 2;
	}

	private void renderMainMenuFooter(class_332 graphics) {
		int lineColor = this.getLineColor();
		class_2561 credit = this.buildMainMenuCredit();
		int photoX = this.contentX + this.contentWidth - CONTENT_INNER_PADDING - MAIN_MENU_PHOTO_DISPLAY_SIZE;
		int photoY = this.contentY + this.contentHeight - CONTENT_INNER_PADDING - MAIN_MENU_PHOTO_DISPLAY_SIZE;
		int creditWidth = this.field_22793.method_27525(credit);
		int creditX = photoX - MAIN_MENU_CREDIT_GAP - creditWidth;
		int creditY = photoY + (MAIN_MENU_PHOTO_DISPLAY_SIZE - this.field_22793.field_2000) / 2;

		graphics.method_25293(
				class_10799.field_56883,
				MAIN_MENU_PHOTO,
				photoX,
				photoY,
				0.0f,
				0.0f,
				MAIN_MENU_PHOTO_DISPLAY_SIZE,
				MAIN_MENU_PHOTO_DISPLAY_SIZE,
				MAIN_MENU_PHOTO_TEXTURE_SIZE,
				MAIN_MENU_PHOTO_TEXTURE_SIZE,
				MAIN_MENU_PHOTO_TEXTURE_SIZE,
				MAIN_MENU_PHOTO_TEXTURE_SIZE,
				IMAGE_COLOR
		);

		int photoFrameX = photoX - MAIN_MENU_PHOTO_FRAME_PADDING;
		int photoFrameY = photoY - MAIN_MENU_PHOTO_FRAME_PADDING;
		int photoFrameSize = MAIN_MENU_PHOTO_DISPLAY_SIZE + MAIN_MENU_PHOTO_FRAME_PADDING * 2;
		graphics.method_73198(photoFrameX, photoFrameY, photoFrameSize, photoFrameSize, lineColor);

		graphics.method_51439(this.field_22793, credit, creditX, creditY, -1, true);

		int groupLeft = creditX - MAIN_MENU_CREDIT_GROUP_PADDING;
		int groupTop = Math.min(creditY, photoFrameY) - MAIN_MENU_CREDIT_GROUP_PADDING;
		int groupWidth = photoFrameX + photoFrameSize - groupLeft + MAIN_MENU_CREDIT_GROUP_PADDING;
		int groupHeight = Math.max(creditY + this.field_22793.field_2000, photoFrameY + photoFrameSize)
				- groupTop
				+ MAIN_MENU_CREDIT_GROUP_PADDING;
		graphics.method_73198(groupLeft, groupTop, groupWidth, groupHeight, lineColor);
	}

	private void renderTextContent(class_332 graphics, class_2561 text) {
		this.renderTextContentAt(
				graphics,
				text,
				this.contentX + CONTENT_INNER_PADDING,
				this.contentY + CONTENT_INNER_PADDING,
				this.contentWidth - CONTENT_INNER_PADDING * 2,
				Integer.MAX_VALUE
		);
	}

	int renderTextContentAt(class_332 graphics, class_2561 text, int textX, int textY, int textWidth) {
		return this.renderTextContentAt(graphics, text, textX, textY, textWidth, Integer.MAX_VALUE);
	}

	int getFontLineHeight() {
		return this.field_22793.field_2000;
	}

	private int renderTextContentAt(
			class_332 graphics,
			class_2561 text,
			int textX,
			int textY,
			int textWidth,
			int maxTextBottom
	) {
		return this.renderStyledTextBlock(graphics, text, textX, textY, textWidth, maxTextBottom);
	}

	private int renderStyledTextBlock(
			class_332 graphics,
			class_2561 text,
			int textX,
			int textY,
			int textWidth,
			int maxTextBottom
	) {
		for (class_5481 line : this.field_22793.method_1728(text, textWidth)) {
			if (textY + this.field_22793.field_2000 > maxTextBottom) {
				break;
			}
			graphics.method_51430(this.field_22793, line, textX, textY, -1, true);
			textY += this.field_22793.field_2000;
		}
		return textY;
	}

	private int renderScaledTextBlock(
			class_332 graphics,
			class_2561 text,
			int textX,
			int textY,
			int textWidth,
			float scale,
			int maxTextBottom
	) {
		int scaledLineHeight = (int) Math.ceil(this.field_22793.field_2000 * scale);
		int scaledWidth = Math.max(1, (int) (textWidth / scale));
		List<class_5481> lines = this.field_22793.method_1728(text, scaledWidth);
		int blockHeight = scaledLineHeight * lines.size();
		if (textY + blockHeight > maxTextBottom) {
			return textY;
		}

		var pose = graphics.method_51448();
		pose.pushMatrix();
		pose.translate(textX, textY);
		pose.scale(scale, scale);
		int localY = 0;
		for (class_5481 line : lines) {
			graphics.method_51430(this.field_22793, line, 0, localY, -1, true);
			localY += this.field_22793.field_2000;
		}
		pose.popMatrix();
		return textY + blockHeight;
	}

	@Override
	public boolean method_25421() {
		ModConfig config = ModConfig.get();
		return config.pauseOnOpen && this.field_22787 != null && this.field_22787.method_47392();
	}

	int getContentX() {
		return this.contentX;
	}

	int getContentY() {
		return this.contentY;
	}

	int getContentWidth() {
		return this.contentWidth;
	}

	int getContentHeight() {
		return this.contentHeight;
	}

	int getNavY() {
		return this.navY;
	}

	<T extends net.minecraft.class_364 & net.minecraft.class_4068 & net.minecraft.class_6379> T addContentWidget(
			T widget
	) {
		return this.method_37063(widget);
	}
}
