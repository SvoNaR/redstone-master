package ru.redstonemaster.client.video;

import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_357;

public final class PseudoVideoSeekSlider extends class_357 {
	private boolean widgetScrubbing;
	private boolean syncing;

	public PseudoVideoSeekSlider(int x, int y, int width, int height) {
		super(x, y, width, height, class_2561.method_43473(), 0.0);
	}

	@Override
	protected void method_25344() {
		if (this.syncing) {
			return;
		}
		PseudoVideoService service = PseudoVideoService.get();
		if (!this.widgetScrubbing) {
			this.widgetScrubbing = true;
			service.beginScrub();
		}
		service.seekToProgress(this.field_22753);
	}

	@Override
	protected void method_25346() {
	}

	@Override
	public void method_25357(class_11909 event) {
		super.method_25357(event);
		if (this.widgetScrubbing) {
			this.widgetScrubbing = false;
			PseudoVideoService.get().endScrub();
		}
	}

	public void syncFromPlayback() {
		if (this.widgetScrubbing || PseudoVideoService.get().getPrepareState() != PseudoVideoService.PrepareState.READY) {
			return;
		}
		double progress = PseudoVideoService.get().getPlaybackProgress();
		if (Math.abs(this.field_22753 - progress) < 0.0005) {
			return;
		}
		this.syncing = true;
		this.method_25347(progress);
		this.syncing = false;
	}
}
