package ru.redstonemaster.client.comments;

import ru.redstonemaster.RedstoneMasterClient;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class ModCommentAvatarCache {
	private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2, r -> {
		Thread thread = new Thread(r, "redstone-master-comment-avatar");
		thread.setDaemon(true);
		return thread;
	});
	private static final Map<Long, Entry> ENTRIES = new ConcurrentHashMap<>();
	private static final class_2960 FALLBACK = class_2960.method_60655(
			RedstoneMasterClient.MOD_ID,
			"textures/gui/profile_avatar.png");

	private record Entry(class_2960 textureId, int width, int height) {
	}

	private ModCommentAvatarCache() {
	}

	public static AvatarDraw get(long commentId, String avatarUrl) {
		Entry entry = ENTRIES.get(commentId);
		if (entry != null) {
			return new AvatarDraw(entry.textureId(), entry.width(), entry.height());
		}
		if (avatarUrl != null && !avatarUrl.isBlank()) {
			scheduleLoad(commentId, avatarUrl);
		}
		return new AvatarDraw(FALLBACK, 8, 8);
	}

	private static void scheduleLoad(long commentId, String avatarUrl) {
		EXECUTOR.execute(() -> {
			if (ENTRIES.containsKey(commentId)) {
				return;
			}
			try {
				HttpRequest request = HttpRequest.newBuilder()
						.uri(URI.create(avatarUrl))
						.GET()
						.build();
				HttpResponse<InputStream> response = HttpClient.newHttpClient()
						.send(request, HttpResponse.BodyHandlers.ofInputStream());
				if (response.statusCode() != 200) {
					return;
				}
				try (InputStream inputStream = response.body();
					 class_1011 image = class_1011.method_4309(inputStream)) {
					register(commentId, image);
				}
			} catch (IOException | InterruptedException ignored) {
				if (ignored instanceof InterruptedException) {
					Thread.currentThread().interrupt();
				}
			}
		});
	}

	private static void register(long commentId, class_1011 image) {
		int width = image.method_4307();
		int height = image.method_4323();
		class_1011 copy = new class_1011(width, height, false);
		copy.method_4317(image);
		class_310 client = class_310.method_1551();
		if (client == null) {
			copy.close();
			return;
		}
		client.execute(() -> {
			class_2960 textureId = class_2960.method_60655(
					RedstoneMasterClient.MOD_ID,
					"dynamic/comment_avatar/" + commentId);
			client.method_1531().method_4615(textureId);
			class_1043 dynamicTexture = new class_1043(() -> "comment avatar " + commentId, copy);
			client.method_1531().method_4616(textureId, dynamicTexture);
			ENTRIES.put(commentId, new Entry(textureId, width, height));
		});
	}

	public record AvatarDraw(class_2960 textureId, int width, int height) {
	}
}
