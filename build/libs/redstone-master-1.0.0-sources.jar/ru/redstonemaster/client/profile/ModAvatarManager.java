package ru.redstonemaster.client.profile;

import ru.redstonemaster.RedstoneMasterClient;
import ru.redstonemaster.config.ModConfig;

import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class ModAvatarManager {
	private static final class_2960 FALLBACK_AVATAR = class_2960.method_60655(
			RedstoneMasterClient.MOD_ID, "textures/gui/profile_avatar.png");
	private static final class_2960 DYNAMIC_AVATAR = class_2960.method_60655(
			RedstoneMasterClient.MOD_ID, "dynamic/profile_avatar");
	private static final int FALLBACK_TEXTURE_SIZE = 8;
	private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
		Thread thread = new Thread(r, "redstone-master-avatar");
		thread.setDaemon(true);
		return thread;
	});

	private static final AtomicReference<class_2960> currentAvatar = new AtomicReference<>(FALLBACK_AVATAR);
	private static volatile int textureWidth = FALLBACK_TEXTURE_SIZE;
	private static volatile int textureHeight = FALLBACK_TEXTURE_SIZE;
	private static volatile String loadingUrl = "";

	private ModAvatarManager() {
	}

	public static void ensureGuestAvatar() {
		ModConfig config = ModConfig.get();
		if (config.guestAvatarDefault <= 0) {
			config.guestAvatarDefault = ThreadLocalRandom.current().nextInt(1, 9);
			config.save();
		}
		if (!config.profileLoggedIn) {
			loadFromUrl(buildDefaultAvatarUrl(config.guestAvatarDefault));
		}
	}

	public static void loadProfileAvatar() {
		ModConfig config = ModConfig.get();
		if (config.profileLoggedIn && config.profileAvatarUrl != null && !config.profileAvatarUrl.isBlank()) {
			loadFromUrl(config.profileAvatarUrl);
			return;
		}
		ensureGuestAvatar();
	}

	public static class_2960 getTabAvatarId() {
		return currentAvatar.get();
	}

	public static int getTabAvatarTextureWidth() {
		return textureWidth;
	}

	public static int getTabAvatarTextureHeight() {
		return textureHeight;
	}

	private static String buildDefaultAvatarUrl(int skinIndex) {
		int index = Math.clamp(skinIndex, 1, 8);
		String base = ModConfig.get().webBaseUrl;
		if (base == null || base.isBlank()) {
			base = "http://localhost:8080";
		}
		if (base.endsWith("/")) {
			base = base.substring(0, base.length() - 1);
		}
		return base + "/avatars/defaults/skin" + index + ".png";
	}

	private static void loadFromUrl(String url) {
		if (url == null || url.isBlank() || url.equals(loadingUrl)) {
			return;
		}
		loadingUrl = url;
		EXECUTOR.execute(() -> {
			try {
				HttpRequest request = HttpRequest.newBuilder()
						.uri(URI.create(url))
						.GET()
						.build();
				HttpResponse<InputStream> response = HttpClient.newHttpClient()
						.send(request, HttpResponse.BodyHandlers.ofInputStream());
				if (response.statusCode() != 200) {
					return;
				}
				try (InputStream inputStream = response.body();
					 class_1011 image = class_1011.method_4309(inputStream)) {
					int width = image.method_4307();
					int height = image.method_4323();
					class_1011 copy = new class_1011(width, height, false);
					copy.method_4317(image);
					class_310 client = class_310.method_1551();
					if (client == null) {
						copy.close();
						return;
					}
					client.execute(() -> registerTexture(copy, width, height));
				}
			} catch (Exception ignored) {
			}
		});
	}

	private static void registerTexture(class_1011 image, int width, int height) {
		class_310 client = class_310.method_1551();
		if (client == null) {
			image.close();
			return;
		}
		client.method_1531().method_4615(DYNAMIC_AVATAR);
		class_1043 dynamicTexture = new class_1043(() -> "redstone-master profile avatar", image);
		client.method_1531().method_4616(DYNAMIC_AVATAR, dynamicTexture);
		textureWidth = width;
		textureHeight = height;
		currentAvatar.set(DYNAMIC_AVATAR);
	}
}
