package ru.redstonemaster.client.profile;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import ru.redstonemaster.RedstoneMasterClient;
import ru.redstonemaster.config.ModConfig;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicReference;

public final class ModAvatarManager {
	private static final class_2960 FALLBACK_AVATAR = class_2960.method_60655(
			RedstoneMasterClient.MOD_ID, "textures/gui/profile_avatar.png");
	private static final class_2960 DYNAMIC_AVATAR = class_2960.method_60655(
			RedstoneMasterClient.MOD_ID, "dynamic/profile_avatar");
	private static final int FALLBACK_TEXTURE_SIZE = 8;
	private static final int GUEST_AVATAR_COUNT = 8;
	private static final int GUEST_TEXTURE_SIZE = 8;
	private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
		Thread thread = new Thread(r, "redstone-master-avatar");
		thread.setDaemon(true);
		return thread;
	});

	private static final AtomicReference<class_2960> currentAvatar = new AtomicReference<>(FALLBACK_AVATAR);
	private static volatile int textureWidth = FALLBACK_TEXTURE_SIZE;
	private static volatile int textureHeight = FALLBACK_TEXTURE_SIZE;
	private static volatile String loadingUrl = "";

	private ModAvatarManager() {
	}

	public static void ensureGuestAvatar() {
		ModConfig config = ModConfig.get();
		if (config.guestAvatarDefault <= 0) {
			config.guestAvatarDefault = ThreadLocalRandom.current().nextInt(1, GUEST_AVATAR_COUNT + 1);
			config.save();
		}
		if (!config.profileLoggedIn) {
			applyGuestAvatar(config.guestAvatarDefault);
		}
	}

	public static void loadProfileAvatar() {
		ModConfig config = ModConfig.get();
		if (config.profileLoggedIn) {
			Path cachePath = getProfileAvatarCachePath(config.profileUsername);
			if (Files.exists(cachePath)) {
				loadFromFile(cachePath);
			}
			if (config.profileAvatarUrl != null && !config.profileAvatarUrl.isBlank()) {
				loadFromUrl(config.profileAvatarUrl, cachePath);
			} else if (!Files.exists(cachePath)) {
				useFallbackAvatar();
			}
			return;
		}
		loadingUrl = "";
		ensureGuestAvatar();
	}

	/** Сброс дедупликации загрузки после смены профиля (новый вход). */
	public static void resetPendingLoads() {
		loadingUrl = "";
	}

	/** После выхода из аккаунта — случайная стандартная аватарка (skin1–skin8) из ресурсов мода. */
	public static void resetToDefaultGuestAvatar() {
		ModConfig config = ModConfig.get();
		int skin = ThreadLocalRandom.current().nextInt(1, GUEST_AVATAR_COUNT + 1);
		config.guestAvatarDefault = skin;
		config.save();
		resetPendingLoads();
		applyGuestAvatar(skin);
	}

	public static class_2960 getTabAvatarId() {
		return currentAvatar.get();
	}

	public static int getTabAvatarTextureWidth() {
		return textureWidth;
	}

	public static int getTabAvatarTextureHeight() {
		return textureHeight;
	}

	private static Path getProfileAvatarCachePath(String username) {
		String safeName = sanitizeUsername(username);
		return FabricLoader.getInstance()
				.getConfigDir()
				.resolve("redstone-master/profile_avatars/" + safeName + ".png");
	}

	private static String sanitizeUsername(String username) {
		if (username == null || username.isBlank()) {
			return "profile";
		}
		String sanitized = username.trim().replaceAll("[^a-zA-Z0-9._-]", "_");
		return sanitized.isBlank() ? "profile" : sanitized;
	}

	private static class_2960 defaultGuestAvatarId(int skinIndex) {
		int index = Math.clamp(skinIndex, 1, GUEST_AVATAR_COUNT);
		return class_2960.method_60655(
				RedstoneMasterClient.MOD_ID,
				"textures/gui/avatars/default/skin" + index + ".png");
	}

	private static void applyGuestAvatar(int skinIndex) {
		class_2960 avatarId = defaultGuestAvatarId(skinIndex);
		class_310 client = class_310.method_1551();
		Runnable apply = () -> {
			if (client != null && client.method_1478().method_14486(avatarId).isEmpty()) {
				useFallbackAvatar();
				return;
			}
			if (client != null) {
				client.method_1531().method_4615(DYNAMIC_AVATAR);
			}
			textureWidth = GUEST_TEXTURE_SIZE;
			textureHeight = GUEST_TEXTURE_SIZE;
			currentAvatar.set(avatarId);
		};
		if (client != null) {
			client.execute(apply);
		} else {
			apply.run();
		}
	}

	private static void loadFromFile(Path cachePath) {
		if (cachePath == null) {
			return;
		}
		EXECUTOR.execute(() -> {
			try {
				if (!Files.exists(cachePath)) {
					return;
				}
				try (class_1011 image = class_1011.method_4309(Files.newInputStream(cachePath))) {
					registerImageCopy(image);
				}
			} catch (IOException ignored) {
			}
		});
	}

	private static void loadFromUrl(String url, Path cachePath) {
		if (url == null || url.isBlank() || url.equals(loadingUrl)) {
			return;
		}
		loadingUrl = url;
		EXECUTOR.execute(() -> {
			try {
				HttpRequest request = HttpRequest.newBuilder()
						.uri(URI.create(url))
						.GET()
						.build();
				HttpResponse<InputStream> response = HttpClient.newHttpClient()
						.send(request, HttpResponse.BodyHandlers.ofInputStream());
				if (response.statusCode() != 200) {
					return;
				}
				try (InputStream inputStream = response.body();
					 class_1011 image = class_1011.method_4309(inputStream)) {
					if (cachePath != null) {
						saveToCache(image, cachePath);
					}
					registerImageCopy(image);
				}
			} catch (Exception ignored) {
			}
		});
	}

	private static void saveToCache(class_1011 image, Path cachePath) {
		try {
			Files.createDirectories(cachePath.getParent());
			image.method_4314(cachePath);
		} catch (IOException ignored) {
		}
	}

	private static void registerImageCopy(class_1011 image) {
		int width = image.method_4307();
		int height = image.method_4323();
		class_1011 copy = new class_1011(width, height, false);
		copy.method_4317(image);
		class_310 client = class_310.method_1551();
		if (client == null) {
			copy.close();
			return;
		}
		client.execute(() -> registerTexture(copy, width, height));
	}

	private static void useFallbackAvatar() {
		class_310 client = class_310.method_1551();
		if (client != null) {
			client.execute(() -> {
				textureWidth = FALLBACK_TEXTURE_SIZE;
				textureHeight = FALLBACK_TEXTURE_SIZE;
				currentAvatar.set(FALLBACK_AVATAR);
			});
		}
	}

	private static void registerTexture(class_1011 image, int width, int height) {
		class_310 client = class_310.method_1551();
		if (client == null) {
			image.close();
			return;
		}
		client.method_1531().method_4615(DYNAMIC_AVATAR);
		class_1043 dynamicTexture = new class_1043(() -> "redstone-master profile avatar", image);
		client.method_1531().method_4616(DYNAMIC_AVATAR, dynamicTexture);
		textureWidth = width;
		textureHeight = height;
		currentAvatar.set(DYNAMIC_AVATAR);
	}
}
