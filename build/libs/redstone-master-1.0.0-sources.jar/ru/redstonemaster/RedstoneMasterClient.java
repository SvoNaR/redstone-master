package ru.redstonemaster;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import ru.redstonemaster.client.gui.RedstoneMasterScreen;
import ru.redstonemaster.config.ModConfig;
import ru.redstonemaster.config.ModContentLanguage;

public class RedstoneMasterClient implements ClientModInitializer {
	public static final String MOD_ID = "redstone-master";

	public static final class_304.class_11900 KEY_CATEGORY = class_304.class_11900.method_74698(
			class_2960.method_60655(MOD_ID, "main")
	);

	public static class_304 openGuiKey;

	@Override
	public void onInitializeClient() {
		ModConfig.load();

		openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.redstone-master.open_gui",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_RIGHT_BRACKET,
				KEY_CATEGORY
		));

		// В мире без открытого экрана — стандартный consumeClick().
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.field_1755 != null) {
				return;
			}
			while (openGuiKey.method_1436()) {
				handleOpenKey(client);
			}
		});

		// На экранах меню consumeClick() не срабатывает — регистрируем обработчик на каждый Screen.
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			ScreenKeyboardEvents.beforeKeyPress(screen).register((activeScreen, event) -> {
				if (openGuiKey.method_1417(event)) {
					handleOpenKey(client);
				}
			});
		});
	}

	public static void handleOpenKey(net.minecraft.class_310 client) {
		if (client.field_1755 instanceof RedstoneMasterScreen modScreen) {
			if (ModConfig.get().closeOnRepeatKey) {
				modScreen.method_25419();
			}
			return;
		}

		ModConfig config = ModConfig.get();
		if (config.initializeLanguageOnFirstOpen()) {
			ModContentLanguage.clearCache();
		}
		class_437 previous = client.field_1755;
		client.method_1507(new RedstoneMasterScreen(previous));
	}
}
