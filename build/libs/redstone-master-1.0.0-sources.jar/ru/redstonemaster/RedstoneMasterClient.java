package ru.redstonemaster;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import ru.redstonemaster.client.auth.ModWebAuthService;
import ru.redstonemaster.client.gui.RedstoneMasterScreen;
import ru.redstonemaster.client.profile.ModAvatarManager;
import ru.redstonemaster.client.sync.ModTutorialSyncService;
import ru.redstonemaster.client.video.PseudoVideoService;
import ru.redstonemaster.config.ModConfig;
import ru.redstonemaster.config.ModContentLanguage;

public class RedstoneMasterClient implements ClientModInitializer {
	public static final String MOD_ID = "redstone-master";

	public static final class_304.class_11900 KEY_CATEGORY = class_304.class_11900.method_74698(
			class_2960.method_60655(MOD_ID, "main")
	);

	public static class_304 openGuiKey;
	public static class_304 navigateBackKey;
	public static class_304 navigateForwardKey;

	/** Блокирует повторное открытие после закрытия через beforeKeyPress (в мире consumeClick ещё не съеден). */
	private static boolean suppressNextOpenKey;

	@Override
	public void onInitializeClient() {
		ModConfig.load();
		ModAvatarManager.ensureGuestAvatar();
		ModAvatarManager.loadProfileAvatar();

		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ModTutorialSyncService.get().pushProgressBlocking());

		openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.redstone-master.open_gui",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_RIGHT_BRACKET,
				KEY_CATEGORY
		));

		navigateBackKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.redstone-master.open_gui.navigation_back",
				class_3675.class_307.field_1672,
				GLFW.GLFW_MOUSE_BUTTON_4,
				KEY_CATEGORY
		));

		navigateForwardKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.redstone-master.open_gui.navigation_forward",
				class_3675.class_307.field_1672,
				GLFW.GLFW_MOUSE_BUTTON_5,
				KEY_CATEGORY
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			ModWebAuthService.get().tick(client);
			PseudoVideoService.get().tick(client);
			if (client.field_1755 instanceof RedstoneMasterScreen modScreen) {
				if (ModWebAuthService.get().consumeProfileUiStale()) {
					modScreen.rebuildAllWidgets();
				}
				while (openGuiKey.method_1436()) {
					handleOpenKey(client);
				}
				while (navigateBackKey.method_1436()) {
					modScreen.navigateBack();
				}
				while (navigateForwardKey.method_1436()) {
					modScreen.navigateForward();
				}
				return;
			}
			if (client.field_1755 != null) {
				ModWebAuthService.get().tick(client);
				return;
			}
			while (openGuiKey.method_1436()) {
				handleOpenKey(client);
			}
		});

		// На экранах меню consumeClick() не срабатывает — регистрируем обработчик на каждый Screen.
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			ScreenKeyboardEvents.beforeKeyPress(screen).register((activeScreen, event) -> {
				if (openGuiKey.method_1417(event)) {
					if (activeScreen instanceof RedstoneMasterScreen modScreen) {
						if (ModConfig.get().closeOnRepeatKey) {
							suppressNextOpenKey = true;
							modScreen.method_25419();
						}
						while (openGuiKey.method_1436()) {
						}
					} else {
						handleOpenKey(client);
					}
					return;
				}
				if (activeScreen instanceof RedstoneMasterScreen modScreen) {
					if (navigateBackKey.method_1417(event)) {
						modScreen.navigateBack();
					} else if (navigateForwardKey.method_1417(event)) {
						modScreen.navigateForward();
					}
				}
			});
		});
	}

	public static void handleOpenKey(net.minecraft.class_310 client) {
		if (client.field_1755 instanceof RedstoneMasterScreen modScreen) {
			if (ModConfig.get().closeOnRepeatKey) {
				modScreen.method_25419();
			}
			while (openGuiKey.method_1436()) {
			}
			return;
		}

		if (suppressNextOpenKey) {
			suppressNextOpenKey = false;
			// Подавляем только «хвост» того же нажатия в мире (screen == null).
			// После закрытия из меню screen — TitleScreen; следующее ] должно открыть мод.
			if (client.field_1755 == null) {
				while (openGuiKey.method_1436()) {
				}
				return;
			}
		}

		ModConfig config = ModConfig.get();
		if (config.initializeLanguageOnFirstOpen()) {
			ModContentLanguage.clearCache();
		}
		class_437 previous = client.field_1755;
		client.method_1507(new RedstoneMasterScreen(previous));
	}
}
