package ru.redstonemaster.config;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import ru.redstonemaster.client.gui.tutorial.TutorialCatalog;
import ru.redstonemaster.client.gui.tutorial.TutorialTextures;

import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;

public final class ModContentLanguage {
	private static final Gson GSON = new Gson();
	private static final Type LANG_MAP_TYPE = new TypeToken<Map<String, String>>() {
	}.getType();

	private static Map<String, String> ruStrings;
	private static Map<String, String> enStrings;

	private ModContentLanguage() {
	}

	public static void clearCache() {
		ruStrings = null;
		enStrings = null;
		TutorialCatalog.clearCache();
		TutorialTextures.clearCache();
	}

	public static class_2561 translatable(String key) {
		return class_2561.method_43470(get(key));
	}

	public static class_2561 translatable(String key, Object arg) {
		return class_2561.method_43470(format(key, arg));
	}

	public static String format(String key, Object arg) {
		String template = get(key);
		return String.format(template, arg);
	}

	public static String get(String key) {
		if (ModConfig.get().autoLanguage) {
			return class_2477.method_10517().method_4679(key, key);
		}
		return getMap(ModConfig.get().manualLanguage).getOrDefault(key, key);
	}

	public static class_2561 getLanguageDisplayName(String languageCode) {
		String nameKey = switch (languageCode) {
			case "ru_ru" -> "gui.redstone-master.settings.language.ru";
			case "en_us" -> "gui.redstone-master.settings.language.en";
			default -> "gui.redstone-master.settings.language.unknown";
		};
		return class_2561.method_43470(getMap(languageCode).getOrDefault(nameKey, nameKey));
	}

	public static class_2561 getMinecraftLanguageDisplayName() {
		return getLanguageDisplayName(ModConfig.get().getEffectiveLanguageCode());
	}

	private static Map<String, String> getMap(String languageCode) {
		if ("en_us".equals(languageCode)) {
			if (enStrings == null) {
				enStrings = loadLanguageFile("en_us");
			}
			return enStrings;
		}
		if (ruStrings == null) {
			ruStrings = loadLanguageFile("ru_ru");
		}
		return ruStrings;
	}

	private static Map<String, String> loadLanguageFile(String code) {
		class_310 client = class_310.method_1551();
		if (client == null) {
			return Map.of();
		}

		class_2960 id = class_2960.method_60655("redstone-master", "lang/" + code + ".json");
		try {
			class_3298 resource = client.method_1478().getResourceOrThrow(id);
			try (InputStreamReader reader = new InputStreamReader(resource.method_14482(), StandardCharsets.UTF_8)) {
				Map<String, String> loaded = GSON.fromJson(reader, LANG_MAP_TYPE);
				return loaded != null ? loaded : Map.of();
			}
		} catch (Exception e) {
			return new HashMap<>();
		}
	}
}
