package ru.redstonemaster;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import ru.redstonemaster.client.gui.RedstoneMasterScreen;
import ru.redstonemaster.config.ModConfig;
import ru.redstonemaster.config.ModContentLanguage;

public class RedstoneMasterClient implements ClientModInitializer {
	public static final String MOD_ID = "redstone_master";

	public static final class_304.class_11900 KEY_CATEGORY = class_304.class_11900.method_74698(
			class_2960.method_60655(MOD_ID, "main")
	);

	public static class_304 openGuiKey;

	@Override
	public void onInitializeClient() {
		ModConfig.load();

		openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.redstone_master.open_gui",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_RIGHT_BRACKET,
				KEY_CATEGORY
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openGuiKey.method_1436()) {
				handleOpenKey(client);
			}
		});
	}

	public static void handleOpenKey(net.minecraft.class_310 client) {
		if (client.field_1755 instanceof RedstoneMasterScreen) {
			if (ModConfig.get().closeOnRepeatKey) {
				client.method_1507(null);
			}
		} else {
			ModConfig config = ModConfig.get();
			if (config.initializeLanguageOnFirstOpen()) {
				ModContentLanguage.clearCache();
			}
			client.method_1507(new RedstoneMasterScreen());
		}
	}
}
