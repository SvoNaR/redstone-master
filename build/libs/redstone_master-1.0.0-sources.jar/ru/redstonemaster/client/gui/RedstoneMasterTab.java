package ru.redstonemaster.client.gui;

import net.minecraft.class_2561;

public enum RedstoneMasterTab {
	MAIN_MENU("gui.redstone_master.welcome"),
	TUTORIAL("gui.redstone_master.placeholder"),
	SETTINGS("gui.redstone_master.placeholder"),
	SEARCH("gui.redstone_master.placeholder");

	private final String translationKey;

	RedstoneMasterTab(String translationKey) {
		this.translationKey = translationKey;
	}

	public class_2561 getContent() {
		return class_2561.method_43471(this.translationKey);
	}
}
