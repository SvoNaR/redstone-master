package ru.redstonemaster.client.gui;

import net.minecraft.class_2561;

public enum RedstoneMasterTab {
	WELCOME("gui.redstone_master.welcome"),
	TUTORIAL("gui.redstone_master.placeholder"),
	ABOUT_AUTHOR("gui.redstone_master.placeholder"),
	ABOUT_MOD("gui.redstone_master.placeholder");

	private final String translationKey;

	RedstoneMasterTab(String translationKey) {
		this.translationKey = translationKey;
	}

	public class_2561 getContent() {
		return class_2561.method_43471(this.translationKey);
	}
}
