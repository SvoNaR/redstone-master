package ru.redstonemaster.client.gui;

import net.minecraft.class_2561;
import ru.redstonemaster.config.ModContentLanguage;

public enum RedstoneMasterTab {
	MAIN_MENU("gui.redstone_master.welcome"),
	TUTORIAL("gui.redstone_master.placeholder"),
	SETTINGS(null),
	PROFILE("gui.redstone_master.placeholder");

	private final String translationKey;

	RedstoneMasterTab(String translationKey) {
		this.translationKey = translationKey;
	}

	public class_2561 getContent() {
		if (this.translationKey == null) {
			return class_2561.method_43473();
		}
		return ModContentLanguage.translatable(this.translationKey);
	}

	public static RedstoneMasterTab fromName(String name) {
		if (name == null || name.isBlank()) {
			return null;
		}
		try {
			return RedstoneMasterTab.valueOf(name);
		} catch (IllegalArgumentException e) {
			return null;
		}
	}
}
