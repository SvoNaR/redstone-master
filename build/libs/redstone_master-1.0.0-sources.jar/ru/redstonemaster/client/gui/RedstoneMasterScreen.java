package ru.redstonemaster.client.gui;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

public class RedstoneMasterScreen extends class_437 {
	private static final double PANEL_SCALE = 0.8;
	private static final int PANEL_PADDING = 8;
	private static final int HEADER_HEIGHT = 20;
	private static final int CLOSE_BUTTON_SIZE = 20;

	private RedstoneMasterTab currentTab = RedstoneMasterTab.WELCOME;

	private int panelX;
	private int panelY;
	private int panelWidth;
	private int panelHeight;

	public RedstoneMasterScreen() {
		super(class_2561.method_43470("Redstone Master"));
	}

	@Override
	protected void method_25426() {
		this.updatePanelBounds();
		this.rebuildHeaderButtons();
	}

	private void updatePanelBounds() {
		this.panelWidth = (int) (this.field_22789 * PANEL_SCALE);
		this.panelHeight = (int) (this.field_22790 * PANEL_SCALE);
		this.panelX = (this.field_22789 - this.panelWidth) / 2;
		this.panelY = (this.field_22790 - this.panelHeight) / 2;
	}

	private void rebuildHeaderButtons() {
		this.method_37067();

		int headerY = this.panelY + PANEL_PADDING;
		int tabsAreaWidth = this.panelWidth - PANEL_PADDING * 2 - CLOSE_BUTTON_SIZE - 4;
		int tabWidth = tabsAreaWidth / 3;
		int tabX = this.panelX + PANEL_PADDING;

		this.method_37063(class_4185.method_46430(
						class_2561.method_43471("gui.redstone_master.tab.tutorial"),
						button -> this.selectTab(RedstoneMasterTab.TUTORIAL))
				.method_46434(tabX, headerY, tabWidth, HEADER_HEIGHT)
				.method_46431());

		this.method_37063(class_4185.method_46430(
						class_2561.method_43471("gui.redstone_master.tab.about_author"),
						button -> this.selectTab(RedstoneMasterTab.ABOUT_AUTHOR))
				.method_46434(tabX + tabWidth, headerY, tabWidth, HEADER_HEIGHT)
				.method_46431());

		this.method_37063(class_4185.method_46430(
						class_2561.method_43471("gui.redstone_master.tab.about_mod"),
						button -> this.selectTab(RedstoneMasterTab.ABOUT_MOD))
				.method_46434(tabX + tabWidth * 2, headerY, tabWidth, HEADER_HEIGHT)
				.method_46431());

		int closeX = this.panelX + this.panelWidth - PANEL_PADDING - CLOSE_BUTTON_SIZE;
		this.method_37063(class_4185.method_46430(
						class_2561.method_43470("X"),
						button -> this.method_25419())
				.method_46434(closeX, headerY, CLOSE_BUTTON_SIZE, CLOSE_BUTTON_SIZE)
				.method_46431());
	}

	private void selectTab(RedstoneMasterTab tab) {
		this.currentTab = tab;
	}

	@Override
	public void method_25410(int width, int height) {
		super.method_25410(width, height);
		this.updatePanelBounds();
		this.rebuildHeaderButtons();
	}

	@Override
	public void method_25420(class_332 graphics, int mouseX, int mouseY, float delta) {
		// Оставляем 20% экрана прозрачными — виден мир или фон главного меню.
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
		this.method_57736(graphics, this.panelX, this.panelY, this.panelWidth, this.panelHeight);
		super.method_25394(graphics, mouseX, mouseY, delta);
		this.renderContent(graphics);
	}

	private void renderContent(class_332 graphics) {
		int contentX = this.panelX + PANEL_PADDING + 4;
		int contentY = this.panelY + PANEL_PADDING + HEADER_HEIGHT + 12;
		int contentWidth = this.panelWidth - (PANEL_PADDING + 4) * 2;

		List<class_5481> lines = this.field_22793.method_1728(this.currentTab.getContent(), contentWidth);
		for (class_5481 line : lines) {
			graphics.method_51430(this.field_22793, line, contentX, contentY, 0xFFFFFF, true);
			contentY += this.field_22793.field_2000;
		}
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
