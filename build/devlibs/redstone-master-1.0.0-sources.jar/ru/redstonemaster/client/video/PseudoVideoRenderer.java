package ru.redstonemaster.client.video;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import ru.redstonemaster.config.ModContentLanguage;

public final class PseudoVideoRenderer {
	private static final int COLOR = 0xFFFFFFFF;
	private static final int STATUS_COLOR = 0xFFBBBBBB;
	public static final int FRAME_BORDER_THICKNESS = 1;
	/** 55% от размера, вписанного в ширину контента. */
	private static final float DISPLAY_SCALE = 0.55f;

	private PseudoVideoRenderer() {
	}

	public static int[] getDisplaySize(int maxWidth) {
		PseudoVideoService service = PseudoVideoService.get();
		int texWidth = service.getFrameWidth();
		int texHeight = service.getFrameHeight();
		if (texWidth <= 0 || texHeight <= 0) {
			int placeholderHeight = Math.max(72, Math.round(maxWidth * 9f / 16f));
			int placeholderWidth = Math.max(1, Math.round(placeholderHeight * 16f / 9f));
			return scaleSize(placeholderWidth, placeholderHeight);
		}
		return computeDisplaySize(texWidth, texHeight, maxWidth);
	}

	public static int getFrameOuterWidth(int maxWidth) {
		return getDisplaySize(maxWidth)[0] + FRAME_BORDER_THICKNESS * 2;
	}

	public static int getFrameLeft(int areaX, int maxWidth) {
		int displayWidth = getDisplaySize(maxWidth)[0];
		return areaX + Math.max(0, (maxWidth - displayWidth) / 2) - FRAME_BORDER_THICKNESS;
	}

	public static int measureVideoDisplayHeight(int maxWidth) {
		return getDisplaySize(maxWidth)[1];
	}

	public static int measureHeight(int maxWidth, boolean hasVideo) {
		if (!hasVideo) {
			return 0;
		}
		return measureVideoDisplayHeight(maxWidth) + FRAME_BORDER_THICKNESS * 2;
	}

	public static void drawFrameOutline(GuiGraphics graphics, int x, int y, int width, int height, int borderColor) {
		graphics.renderOutline(x, y, width, height, borderColor);
	}

	private static int[] scaleSize(int width, int height) {
		return new int[] {
				Math.max(1, Math.round(width * DISPLAY_SCALE)),
				Math.max(1, Math.round(height * DISPLAY_SCALE))
		};
	}

	public static int render(
			GuiGraphics graphics,
			Font font,
			int x,
			int y,
			int maxWidth,
			int listTop,
			int contentBottom,
			int borderColor
	) {
		PseudoVideoService service = PseudoVideoService.get();
		PseudoVideoService.PrepareState state = service.getPrepareState();
		if (state == PseudoVideoService.PrepareState.IDLE) {
			return y;
		}

		int[] displaySize = getDisplaySize(maxWidth);
		int displayWidth = displaySize[0];
		int displayHeight = displaySize[1];

		int drawX = x + Math.max(0, (maxWidth - displayWidth) / 2);
		int contentY = y + FRAME_BORDER_THICKNESS;
		int outerX = drawX - FRAME_BORDER_THICKNESS;
		int outerY = y;
		int outerW = displayWidth + FRAME_BORDER_THICKNESS * 2;
		int outerH = displayHeight + FRAME_BORDER_THICKNESS * 2;
		if (outerY + outerH >= listTop && outerY <= contentBottom) {
			drawFrameOutline(graphics, outerX, outerY, outerW, outerH, borderColor);
		}

		if (state == PseudoVideoService.PrepareState.LOADING) {
			drawStatus(
					graphics,
					font,
					drawX,
					contentY,
					displayWidth,
					displayHeight,
					listTop,
					contentBottom,
					"gui.redstone-master.tutorial.video.loading"
			);
			return y + outerH;
		}
		if (state == PseudoVideoService.PrepareState.FAILED) {
			int nextY = drawStatus(
					graphics,
					font,
					drawX,
					contentY,
					displayWidth,
					displayHeight,
					listTop,
					contentBottom,
					"gui.redstone-master.tutorial.video.unavailable"
			);
			String detail = service.getPrepareError();
			if (detail != null && !detail.isBlank()) {
				for (var line : font.split(Component.literal("(" + detail + ")"), displayWidth)) {
					if (nextY + font.lineHeight >= listTop && nextY <= contentBottom) {
						graphics.drawString(font, line, drawX, nextY, STATUS_COLOR, true);
					}
					nextY += font.lineHeight;
				}
			}
			return y + outerH;
		}

		int texWidth = service.getFrameWidth();
		int texHeight = service.getFrameHeight();
		if (texWidth <= 0 || texHeight <= 0 || service.getFrameTextureId() == null) {
			drawStatus(
					graphics,
					font,
					drawX,
					contentY,
					displayWidth,
					displayHeight,
					listTop,
					contentBottom,
					"gui.redstone-master.tutorial.video.unavailable"
			);
			return y + outerH;
		}

		if (contentY + displayHeight >= listTop && contentY <= contentBottom) {
			Identifier textureId = service.getFrameTextureId();
			Minecraft client = Minecraft.getInstance();
			if (client != null) {
				client.getTextureManager().getTexture(textureId);
			}
			graphics.blit(
					RenderPipelines.GUI_TEXTURED,
					textureId,
					drawX,
					contentY,
					0f,
					0f,
					displayWidth,
					displayHeight,
					texWidth,
					texHeight,
					texWidth,
					texHeight,
					COLOR
			);
		}
		return y + outerH;
	}

	private static int drawStatus(
			GuiGraphics graphics,
			Font font,
			int x,
			int y,
			int boxWidth,
			int boxHeight,
			int listTop,
			int contentBottom,
			String key
	) {
		int textY = y + Math.max(0, (boxHeight - font.lineHeight) / 2);
		for (var line : font.split(ModContentLanguage.translatable(key), boxWidth)) {
			if (textY + font.lineHeight >= listTop && textY <= contentBottom) {
				int lineX = x + Math.max(0, (boxWidth - font.width(line)) / 2);
				graphics.drawString(font, line, lineX, textY, STATUS_COLOR, true);
			}
			textY += font.lineHeight;
		}
		return textY;
	}

	private static int[] computeDisplaySize(int texWidth, int texHeight, int maxWidth) {
		int width;
		int height;
		if (texWidth <= maxWidth) {
			width = texWidth;
			height = texHeight;
		} else {
			float scale = (float) maxWidth / texWidth;
			width = maxWidth;
			height = Math.max(1, Math.round(texHeight * scale));
		}
		return scaleSize(width, height);
	}
}
