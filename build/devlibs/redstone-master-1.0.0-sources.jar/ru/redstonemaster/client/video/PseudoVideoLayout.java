package ru.redstonemaster.client.video;

/** Вертикальная раскладка: видео → ползунок → кнопки (рамки вплотную). */
public record PseudoVideoLayout(
		int frameLeft,
		int frameOuterWidth,
		int videoBlockTop,
		int videoBlockHeight,
		int sliderBlockTop,
		int sliderBlockHeight,
		int controlsBlockTop,
		int controlsBlockHeight,
		int controlsFrameLeft,
		int controlsFrameOuterWidth
) {
	public static final int SLIDER_INNER_HEIGHT = 10;

	public static PseudoVideoLayout at(
			int contentTop,
			int textX,
			int textWidth,
			int controlsInnerHeight,
			int controlsInnerWidth
	) {
		int frameLeft = PseudoVideoRenderer.getFrameLeft(textX, textWidth);
		int frameOuterWidth = PseudoVideoRenderer.getFrameOuterWidth(textWidth);
		int border = PseudoVideoRenderer.FRAME_BORDER_THICKNESS;
		int videoBlockHeight = PseudoVideoRenderer.measureHeight(textWidth, true);
		int sliderBlockHeight = SLIDER_INNER_HEIGHT + border * 2;
		int controlsBlockHeight = controlsInnerHeight + border * 2;
		int controlsFrameOuterWidth = controlsInnerWidth + border * 2;
		int controlsFrameLeft = frameLeft + Math.max(0, (frameOuterWidth - controlsFrameOuterWidth) / 2);

		int videoBlockTop = contentTop;
		int sliderBlockTop = videoBlockTop + videoBlockHeight;
		int controlsBlockTop = sliderBlockTop + sliderBlockHeight;

		return new PseudoVideoLayout(
				frameLeft,
				frameOuterWidth,
				videoBlockTop,
				videoBlockHeight,
				sliderBlockTop,
				sliderBlockHeight,
				controlsBlockTop,
				controlsBlockHeight,
				controlsFrameLeft,
				controlsFrameOuterWidth
		);
	}

	public int totalHeight() {
		return this.videoBlockHeight + this.sliderBlockHeight + this.controlsBlockHeight;
	}

	public int sliderWidgetX() {
		return this.frameLeft + PseudoVideoRenderer.FRAME_BORDER_THICKNESS;
	}

	public int sliderWidgetY() {
		return this.sliderBlockTop + PseudoVideoRenderer.FRAME_BORDER_THICKNESS;
	}

	public int sliderWidgetWidth() {
		return this.frameOuterWidth - PseudoVideoRenderer.FRAME_BORDER_THICKNESS * 2;
	}

	public int controlsWidgetY() {
		return this.controlsBlockTop + PseudoVideoRenderer.FRAME_BORDER_THICKNESS;
	}

	public int controlsWidgetX() {
		return this.controlsFrameLeft + PseudoVideoRenderer.FRAME_BORDER_THICKNESS;
	}
}
